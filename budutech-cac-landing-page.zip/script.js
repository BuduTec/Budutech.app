/*
  BUDUTECH CAC LANDING PAGE
  Before launch:
  1. Set WHATSAPP_NUMBER below to the BuduTech WhatsApp number in international format.
  2. Replace the sample testimonials.
  3. Replace the portrait placeholder with Emmanuel's professional photo if desired.
  4. Add the real Meta Pixel ID in index.html.
*/

const WHATSAPP_NUMBER = "234XXXXXXXXXX"; // Example format: 2348012345678

function track(eventName, params = {}) {
  if (typeof window.fbq === "function") {
    window.fbq("track", eventName, params);
  }
  if (window.gtag) {
    window.gtag("event", eventName, params);
  }
  console.log("Tracking:", eventName, params);
}

function whatsappUrl(service) {
  const message =
`Hello BuduTech, I came from your CAC registration page and I'd like to register my business.

Registration type: ${service}

Please guide me on the requirements, cost and next step.`;

  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function updateMainWhatsApp() {
  const select = document.getElementById("service");
  const button = document.getElementById("mainWhatsApp");
  if (!select || !button) return;
  button.href = whatsappUrl(select.value);
}

document.addEventListener("DOMContentLoaded", () => {
  updateMainWhatsApp();

  document.getElementById("service")?.addEventListener("change", updateMainWhatsApp);

  document.querySelectorAll("[data-service]").forEach((el) => {
    el.addEventListener("click", () => {
      const service = el.dataset.service;
      const select = document.getElementById("service");
      if (select) {
        select.value = service;
        updateMainWhatsApp();
      }
      track("ServiceSelected", { service });
    });
  });

  document.querySelectorAll("[data-wa]").forEach((el) => {
    el.addEventListener("click", (event) => {
      const target = el.dataset.service || document.getElementById("service")?.value || "CAC Registration";
      if (WHATSAPP_NUMBER.includes("X")) {
        event.preventDefault();
        alert("Set WHATSAPP_NUMBER in script.js before launch.");
        return;
      }
      el.href = whatsappUrl(target);
      track("Lead", { service: target, source: "landing_page" });
    });
  });

  document.getElementById("mainWhatsApp")?.addEventListener("click", () => {
    const service = document.getElementById("service")?.value || "CAC Registration";
    track("Lead", { service, source: "landing_page_main_cta" });
  });

  track("PageView");
});
