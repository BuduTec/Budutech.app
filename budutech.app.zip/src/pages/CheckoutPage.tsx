import { useState } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { useAppStore } from '../store';
import { ShieldCheck, CheckCircle2, Lock, FileText, Clock } from 'lucide-react';
import { motion } from 'motion/react';
import Header from '../components/Header';

export default function CheckoutPage() {
  const { user, selectedPackage, setApplicationStatus } = useAppStore();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!user || !selectedPackage) {
    return <Navigate to="/" replace />;
  }

  const handlePayment = () => {
    setIsProcessing(true);
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      setApplicationStatus('intake');
    }, 2500);
  };

  const handleContinue = () => {
    navigate('/intake');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {isSuccess ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl mx-auto bg-white p-12 rounded-3xl shadow-xl text-center border border-gray-100"
          >
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="heading-font text-3xl font-bold text-gray-900 mb-4">Payment Successful!</h2>
            <p className="text-gray-600 mb-8 text-lg">
              Your secure payment for the <span className="font-semibold text-gray-900">{selectedPackage.name}</span> package has been confirmed. You are ready to begin the formalization process.
            </p>
            <button 
              onClick={handleContinue}
              className="w-full sm:w-auto px-8 py-4 bg-brand-600 hover:bg-brand-500 text-white rounded-xl font-medium text-lg transition-all shadow-md"
            >
              Proceed to BuduFlow Intake Form
            </button>
          </motion.div>
        ) : (
          <div className="max-w-6xl mx-auto grid lg:grid-cols-12 gap-8 lg:gap-12">
            
            {/* Left Panel: Summary */}
            <div className="lg:col-span-5 space-y-6">
              <div>
                <h2 className="heading-font text-3xl font-bold text-gray-900 mb-2">Order Summary</h2>
                <p className="text-gray-600">Review your package details before completing the secure checkout.</p>
              </div>

              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                <div className="flex justify-between items-start mb-6 pb-6 border-b border-gray-100">
                  <div>
                    <h3 className="font-bold text-xl text-gray-900 heading-font">{selectedPackage.name}</h3>
                    <p className="text-sm text-gray-500">Full Service Registration</p>
                  </div>
                  <span className="font-bold text-xl">₦{selectedPackage.price.toLocaleString()}</span>
                </div>
                
                <ul className="space-y-4 mb-6">
                  {selectedPackage.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start text-sm">
                      <CheckCircle2 className="w-4 h-4 text-brand-500 mr-3 shrink-0 mt-0.5" />
                      <span className="text-gray-700">{feat}</span>
                    </li>
                  ))}
                </ul>

                <div className="bg-gray-50 rounded-xl p-4 flex items-center border border-gray-100">
                  <Clock className="w-5 h-5 text-gray-500 mr-3" />
                  <div className="text-sm">
                    <p className="font-medium text-gray-900">Estimated Timeline</p>
                    <p className="text-gray-500">3 - 5 Business Days</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Panel: Payment */}
            <div className="lg:col-span-7">
              <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8 sm:p-10 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-6 flex items-center text-green-600 text-sm font-medium">
                  <Lock className="w-4 h-4 mr-2" />
                  SSL Secured
                </div>

                <h3 className="heading-font text-2xl font-bold text-gray-900 mb-8">Secure Checkout</h3>

                <div className="space-y-6">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
                    {['Card', 'Bank Transfer', 'USSD'].map((method, idx) => (
                      <div key={idx} className={`p-4 rounded-xl border-2 text-center cursor-pointer transition-all ${idx === 0 ? 'border-brand-500 bg-brand-50 text-brand-700 font-medium' : 'border-gray-200 text-gray-600 hover:border-gray-300'}`}>
                        {method}
                      </div>
                    ))}
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Cardholder Name</label>
                      <input type="text" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" defaultValue={user.email.split('@')[0]} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Card Number</label>
                      <input type="text" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" placeholder="0000 0000 0000 0000" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Date</label>
                        <input type="text" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" placeholder="MM/YY" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">CVV</label>
                        <input type="text" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" placeholder="123" />
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 pt-8 border-t border-gray-100 flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Total to pay</p>
                      <p className="text-2xl font-bold text-gray-900">₦{selectedPackage.price.toLocaleString()}</p>
                    </div>
                    <button
                      onClick={handlePayment}
                      disabled={isProcessing}
                      className="px-8 py-4 bg-gray-900 hover:bg-gray-800 text-white rounded-xl font-medium transition-all flex items-center disabled:opacity-70"
                    >
                      {isProcessing ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-3" />
                          Processing...
                        </>
                      ) : (
                        'Pay Now'
                      )}
                    </button>
                  </div>
                </div>

                {/* Footer logos mock */}
                <div className="mt-8 flex justify-center items-center space-x-6 grayscale opacity-40">
                  <div className="text-xs font-bold tracking-widest uppercase">Paystack</div>
                  <div className="text-xs font-bold tracking-widest uppercase">Flutterwave</div>
                </div>
              </div>
            </div>
            
          </div>
        )}
      </main>
    </div>
  );
}
