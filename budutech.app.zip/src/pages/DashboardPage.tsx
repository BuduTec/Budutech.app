import { Navigate, Link } from 'react-router-dom';
import { useAppStore } from '../store';
import Header from '../components/Header';
import { AlertCircle, FileText, CheckCircle2, ChevronRight, Download, Activity, Clock } from 'lucide-react';
import { motion } from 'motion/react';

const steps = [
  { id: 'intake', name: 'Intake Forms', description: 'Provide corporate details' },
  { id: 'review', name: 'Review', description: 'Admin reviewing data' },
  { id: 'filed', name: 'Filed with Registry', description: 'Processing at CAC' },
  { id: 'completed', name: 'Completed', description: 'Certificates Ready' },
];

export default function DashboardPage() {
  const { user, selectedPackage, applicationStatus, actionNeeded } = useAppStore();

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Find current step index
  const currentStepIndex = steps.findIndex(s => s.id === applicationStatus);
  const activeStep = currentStepIndex >= 0 ? currentStepIndex : 0;

  // Mock documents
  const documents = applicationStatus === 'completed' ? [
    { id: 'cac', name: 'CAC Incorporation Certificate.pdf', status: 'available', size: '2.4 MB' },
    { id: 'tin', name: 'Tax Identification Number.pdf', status: 'available', size: '1.1 MB' },
    { id: 'status', name: 'Certified Status Report.pdf', status: 'available', size: '3.5 MB' },
  ] : [
    { id: 'cac', name: 'CAC Incorporation Certificate.pdf', status: 'pending', size: '--' },
    { id: 'tin', name: 'Tax Identification Number.pdf', status: 'pending', size: '--' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        
        {actionNeeded && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 bg-red-50 border border-red-200 rounded-2xl p-4 sm:p-6 flex items-start sm:items-center justify-between flex-col sm:flex-row gap-4"
          >
            <div className="flex items-start">
              <AlertCircle className="w-6 h-6 text-red-600 mt-0.5 mr-3 shrink-0" />
              <div>
                <h3 className="text-red-800 font-bold heading-font text-lg">Action Required</h3>
                <p className="text-red-700 text-sm mt-1">{actionNeeded}</p>
              </div>
            </div>
            <Link 
              to="/intake" 
              className="whitespace-nowrap px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-medium text-sm transition-colors shadow-sm"
            >
              Update Application
            </Link>
          </motion.div>
        )}

        <div className="mb-10">
          <h1 className="heading-font text-3xl font-bold text-gray-900 mb-2">Welcome back, {user.email.split('@')[0]}</h1>
          <p className="text-gray-600">Track your application progress and access your corporate documents securely.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          
          <div className="lg:col-span-2 space-y-8">
            {/* Progress Tracker */}
            <div className="bg-white rounded-3xl shadow-sm border border-gray-200 p-8">
              <div className="flex items-center justify-between mb-8">
                <h2 className="heading-font text-xl font-bold text-gray-900 flex items-center">
                  <Activity className="w-5 h-5 mr-2 text-brand-500" /> Application Progress
                </h2>
                {selectedPackage && (
                  <span className="inline-flex items-center rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-800">
                    {selectedPackage.name}
                  </span>
                )}
              </div>

              <div className="relative">
                <div className="absolute top-5 left-6 right-6 h-0.5 bg-gray-100 hidden sm:block" />
                <div 
                  className="absolute top-5 left-6 h-0.5 bg-brand-500 hidden sm:block transition-all duration-1000" 
                  style={{ width: `${(activeStep / (steps.length - 1)) * 100}%` }}
                />

                <div className="relative flex flex-col sm:flex-row justify-between gap-6 sm:gap-0">
                  {steps.map((step, idx) => {
                    const isCompleted = idx < activeStep;
                    const isCurrent = idx === activeStep;
                    
                    return (
                      <div key={step.id} className="flex sm:flex-col items-center sm:items-center relative z-10">
                        <div className={`
                          w-10 h-10 rounded-full flex items-center justify-center shrink-0 border-2 transition-colors
                          ${isCompleted ? 'bg-brand-500 border-brand-500 text-white' : ''}
                          ${isCurrent ? 'bg-white border-brand-500 text-brand-600 shadow-lg shadow-brand-500/20' : ''}
                          ${!isCompleted && !isCurrent ? 'bg-white border-gray-200 text-gray-400' : ''}
                        `}>
                          {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : <span className="text-sm font-bold">{idx + 1}</span>}
                        </div>
                        <div className="ml-4 sm:ml-0 sm:mt-4 sm:text-center">
                          <h4 className={`text-sm font-bold ${isCurrent ? 'text-gray-900' : 'text-gray-500'}`}>{step.name}</h4>
                          <p className="text-xs text-gray-400 mt-1 sm:hidden md:block">{step.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {applicationStatus === 'intake' && !actionNeeded && (
                <div className="mt-10 pt-8 border-t border-gray-100 flex items-center justify-between bg-gray-50 -mx-8 -mb-8 p-8 rounded-b-3xl">
                  <div>
                    <h4 className="font-bold text-gray-900">Incomplete Forms</h4>
                    <p className="text-sm text-gray-500 mt-1">Please complete your corporate intake forms to proceed.</p>
                  </div>
                  <Link 
                    to="/intake"
                    className="px-6 py-3 bg-gray-900 hover:bg-gray-800 text-white rounded-xl font-medium text-sm transition-all shadow-sm flex items-center"
                  >
                    Resume Intake <ChevronRight className="w-4 h-4 ml-1" />
                  </Link>
                </div>
              )}
            </div>

            {/* Document Vault */}
            <div className="bg-white rounded-3xl shadow-sm border border-gray-200 p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="heading-font text-xl font-bold text-gray-900 flex items-center">
                  <FileText className="w-5 h-5 mr-2 text-brand-500" /> Secure Document Vault
                </h2>
              </div>
              
              <div className="grid gap-4">
                {documents.map((doc, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 rounded-xl border border-gray-100 hover:border-gray-200 bg-gray-50/50 transition-colors">
                    <div className="flex items-center">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-4 ${doc.status === 'available' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}>
                        <FileText className="w-5 h-5" />
                      </div>
                      <div>
                        <p className={`font-medium text-sm ${doc.status === 'available' ? 'text-gray-900' : 'text-gray-500'}`}>{doc.name}</p>
                        <p className="text-xs text-gray-400 mt-0.5">
                          {doc.status === 'available' ? doc.size : 'Awaiting processing...'}
                        </p>
                      </div>
                    </div>
                    {doc.status === 'available' ? (
                      <button className="p-2 text-brand-600 hover:bg-brand-50 rounded-lg transition-colors" title="Download">
                        <Download className="w-5 h-5" />
                      </button>
                    ) : (
                      <span className="inline-flex items-center text-xs font-medium text-gray-500 bg-gray-100 px-2.5 py-1 rounded-full">
                        <Clock className="w-3 h-3 mr-1" /> Pending
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-8">
            {/* Quick Summary */}
            <div className="bg-gray-900 text-white rounded-3xl p-8 shadow-xl">
              <h3 className="heading-font font-bold text-lg mb-6 text-gray-100">Application Summary</h3>
              <div className="space-y-6">
                <div>
                  <p className="text-gray-400 text-sm mb-1">Service Type</p>
                  <p className="font-medium">{selectedPackage?.name || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">Status</p>
                  <p className="font-medium text-brand-400 capitalize">{applicationStatus.replace('_', ' ')}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">Applicant Email</p>
                  <p className="font-medium truncate">{user.email}</p>
                </div>
              </div>
            </div>

            {/* Support Card */}
            <div className="bg-brand-50 rounded-3xl p-8 border border-brand-100 text-center">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm text-brand-600">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h3 className="heading-font font-bold text-gray-900 mb-2">Need Help?</h3>
              <p className="text-sm text-gray-600 mb-6">Our corporate consultants are available to assist you with your application.</p>
              <button className="w-full py-3 bg-white border border-gray-200 text-gray-900 rounded-xl font-medium text-sm hover:bg-gray-50 transition-colors">
                Contact Support
              </button>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
