import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAppStore, ClientProfile } from '../store';
import Header from '../components/Header';
import { 
  Search, Filter, Copy, AlertCircle, FileText, CheckCircle2, 
  ChevronRight, MessageSquareWarning, ArrowLeft, RefreshCw, User, Briefcase, MapPin, ListOrdered, Share2, ClipboardSignature
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const stages = [
  { id: 'intake', label: 'New Submissions' },
  { id: 'review', label: 'In Review' },
  { id: 'filed', label: 'Filed with Registry' },
  { id: 'completed', label: 'Completed' }
];

export default function AdminHubPage() {
  const { user, clients, updateClient } = useAppStore();
  const [selectedClient, setSelectedClient] = useState<ClientProfile | null>(null);
  const [flagText, setFlagText] = useState('');
  const [showFlagModal, setShowFlagModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  if (!user || user.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  const filteredClients = clients.filter(client => {
    const query = searchQuery.toLowerCase();
    const primaryName = client.intakeData.enterpriseDetails?.proposedNames?.[0] || 
                        client.intakeData.companyDetails?.proposedNames?.[0] || 
                        client.intakeData.ngoDetails?.proposedNames?.[0] || 
                        client.email;
    return primaryName.toLowerCase().includes(query) || client.email.toLowerCase().includes(query);
  });

  const handleCopyData = () => {
    if (!selectedClient) return;
    const { intakeData, email, package: pkg } = selectedClient;
    const isNGO = pkg.type === 'ngo';
    const isCorporate = pkg.type === 'corporate';
    
    let text = '';

    if (isNGO) {
      const ngo = intakeData.ngoDetails;
      text = `
=========================================
CAC NGO REGISTRATION SUBMISSION DETAIL
=========================================
PACKAGE: ${pkg.name} (NGO)
CLIENT EMAIL: ${email}
DATE: ${selectedClient.submittedAt || 'N/A'}

PROPOSED NGO NAMES:
1. ${ngo.proposedNames[0] || 'N/A'}
2. ${ngo.proposedNames[1] || 'N/A'}
3. ${ngo.proposedNames[2] || 'N/A'}

MISSION STATEMENT:
${ngo.mission || 'N/A'}

AUTHORIZED REPRESENTATIVE:
Name: ${ngo.representative.firstName} ${ngo.representative.otherName} ${ngo.representative.surname}
DOB: ${ngo.representative.dob} | Gender: ${ngo.representative.gender} | Nationality: ${ngo.representative.nationality}
Phone: ${ngo.representative.phone} | Email: ${ngo.representative.email} | Occupation: ${ngo.representative.occupation}

REGISTERED OFFICE ADDRESS:
${ngo.officeAddress.houseNumber}, ${ngo.officeAddress.streetName}, ${ngo.officeAddress.city}, ${ngo.officeAddress.lga}, ${ngo.officeAddress.state} State

BOARD OF TRUSTEES (BOT):
${ngo.trustees.map((t, idx) => `
[Trustee #${idx + 1}]
Full Name: ${t.fullName}
Role: ${t.role}
NIN: ${t.nin}
DOB: ${t.dob} | Gender: ${t.gender}
Occupation: ${t.occupation}
Address: ${t.address}
`).join('\n')}

AIMS AND OBJECTIVES:
${ngo.aimsAndObjectives.join('\n')}
=========================================
      `.trim();
    } else if (isCorporate) {
      const corp = intakeData.companyDetails;
      text = `
=========================================
CAC LTD REGISTRATION SUBMISSION DETAIL
=========================================
PACKAGE: ${pkg.name} (LTD Company)
CLIENT EMAIL: ${email}
DATE: ${selectedClient.submittedAt || 'N/A'}

PROPOSED COMPANY NAMES:
1. ${corp.proposedNames[0] || 'N/A'}
2. ${corp.proposedNames[1] || 'N/A'}

MEMORANDUM OBJECTS:
${corp.objectsOfMemorandum.join('\n')}

DIRECTORS:
${corp.directors.map((d, idx) => `
[Director #${idx + 1}]
Name: ${d.firstName} ${d.otherName} ${d.surname}
DOB: ${d.dob} | Gender: ${d.gender} | Nationality: ${d.nationality}
Phone: ${d.phone} | Email: ${d.email}
Address: ${d.address.houseNumber} ${d.address.streetName}, ${d.address.city}, ${d.address.lga}, ${d.address.state} State
ID details: ${d.idType} - ${d.idNumber}
`).join('\n')}

SHAREHOLDERS & EQUITY SHARING:
${corp.shareholders.map((s, idx) => `
[Shareholder #${idx + 1}]
Name: ${s.firstName} ${s.otherName} ${s.surname}
DOB: ${s.dob} | Gender: ${s.gender} | Nationality: ${s.nationality}
Phone: ${s.phone} | Email: ${s.email}
Address: ${s.address.houseNumber} ${s.address.streetName}, ${s.address.city}, ${s.address.lga}, ${s.address.state} State
ID details: ${s.idType} - ${s.idNumber}
Shareholding: ${s.shares}% of Equity
`).join('\n')}

SHARE CAPITAL STATUS:
Total Shares Offered: ${corp.shareCapitalBreakdown.totalShares.toLocaleString()}
Nominal Value Per Share: ₦${corp.shareCapitalBreakdown.nominalValue}
Number of Shareholders: ${corp.shareCapitalBreakdown.numShareholders}

WITNESS INFORMATION:
Name: ${corp.witness.firstName} ${corp.witness.otherName} ${corp.witness.surname}
Phone: ${corp.witness.phone} | Email: ${corp.witness.email}
Address: ${corp.witness.address.houseNumber} ${corp.witness.address.streetName}, ${corp.witness.address.city}, ${corp.witness.address.lga}, ${corp.witness.address.state} State
=========================================
      `.trim();
    } else {
      // Enterprise Business Name
      const ent = intakeData.enterpriseDetails;
      text = `
=========================================
CAC BUSINESS NAME (ENTERPRISE) SUBMISSION
=========================================
PACKAGE: ${pkg.name} (Enterprise)
CLIENT EMAIL: ${email}
DATE: ${selectedClient.submittedAt || 'N/A'}

PROPOSED BUSINESS NAMES:
1. ${ent.proposedNames[0] || 'N/A'}
2. ${ent.proposedNames[1] || 'N/A'}

PROPRIETOR PERSONAL DETAILS:
Name: ${ent.personalDetails.firstName} ${ent.personalDetails.otherName} ${ent.personalDetails.surname}
DOB: ${ent.personalDetails.dob} | Gender: ${ent.personalDetails.gender}
Phone: ${ent.personalDetails.phone} | Email: ${ent.personalDetails.email}
NIN: ${ent.personalDetails.nin}

RESIDENTIAL ADDRESS:
${ent.homeAddress.houseNumber} ${ent.homeAddress.streetName}, ${ent.homeAddress.city}, ${ent.homeAddress.lga}, ${ent.homeAddress.state} State

BUSINESS ADDRESS:
${ent.businessAddress.houseNumber} ${ent.businessAddress.streetName}, ${ent.businessAddress.city}, ${ent.businessAddress.lga}, ${ent.businessAddress.state} State

NATURE OF BUSINESS:
${ent.natureOfBusiness || 'N/A'}
=========================================
      `.trim();
    }

    navigator.clipboard.writeText(text);
    alert('Smart Copy Completed! Raw regulatory data is successfully formatted & copied to clipboard.');
  };

  const handleSendFlag = () => {
    if (!selectedClient || !flagText.trim()) return;
    updateClient(selectedClient.id, { actionNeeded: flagText });
    setSelectedClient(prev => prev ? { ...prev, actionNeeded: flagText } : null);
    setShowFlagModal(false);
    setFlagText('');
  };

  const moveClient = (id: string, newStatus: ClientProfile['status']) => {
    updateClient(id, { status: newStatus });
    if (selectedClient?.id === id) {
      setSelectedClient(prev => prev ? { ...prev, status: newStatus } : null);
    }
  };

  const renderClientDetailContent = (client: ClientProfile) => {
    const pkgType = client.package.type;
    const data = client.intakeData;

    if (pkgType === 'ngo') {
      const ngo = data.ngoDetails;
      return (
        <div className="space-y-6">
          {/* Representative */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <User className="w-4 h-4 mr-1.5" /> Authorized Representative (Section 1)
            </h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-xs text-gray-500 block">Full Name</span>
                <span className="font-bold text-gray-900">{ngo.representative.firstName} {ngo.representative.otherName} {ngo.representative.surname}</span>
              </div>
              <div>
                <span className="text-xs text-gray-500 block">Date of Birth / Gender</span>
                <span className="font-semibold text-gray-900">{ngo.representative.dob} ({ngo.representative.gender})</span>
              </div>
              <div>
                <span className="text-xs text-gray-500 block">Nationality / Occupation</span>
                <span className="font-semibold text-gray-900">{ngo.representative.nationality} — {ngo.representative.occupation}</span>
              </div>
              <div>
                <span className="text-xs text-gray-500 block">Phone & Email</span>
                <span className="font-semibold text-gray-900">{ngo.representative.phone} / {ngo.representative.email}</span>
              </div>
            </div>
          </div>

          {/* Names & Mission */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <Briefcase className="w-4 h-4 mr-1.5" /> Proposed Names & Mission (Section 2)
            </h4>
            <div className="space-y-3">
              <div>
                <span className="text-xs text-gray-500 block">Proposed Name Choices</span>
                <ol className="list-decimal pl-5 text-sm font-bold text-gray-900">
                  {ngo.proposedNames.map((n, i) => n ? <li key={i}>{n}</li> : null)}
                </ol>
              </div>
              <div>
                <span className="text-xs text-gray-500 block">NGO Mission Statement</span>
                <p className="text-sm font-semibold text-gray-800 italic bg-gray-50 p-3 rounded-xl border border-gray-100">{ngo.mission}</p>
              </div>
            </div>
          </div>

          {/* Office Address */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <MapPin className="w-4 h-4 mr-1.5" /> Registered Office Address (Section 3)
            </h4>
            <p className="text-sm font-bold text-gray-900">
              {ngo.officeAddress.houseNumber}, {ngo.officeAddress.streetName}, {ngo.officeAddress.city}, {ngo.officeAddress.lga}, {ngo.officeAddress.state} State
            </p>
            <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
              <span>Attached Document: Utility Bill</span>
              <span className="text-green-600 bg-green-50 px-2 py-0.5 rounded font-bold">Uploaded</span>
            </div>
          </div>

          {/* Board of Trustees */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <User className="w-4 h-4 mr-1.5" /> Board of Trustees (BOT) (Section 4)
            </h4>
            <div className="space-y-4">
              {ngo.trustees.map((tr, idx) => (
                <div key={tr.id} className="p-3 bg-gray-50 rounded-xl border border-gray-100 space-y-2">
                  <div className="flex justify-between">
                    <span className="font-bold text-sm text-gray-900">{tr.fullName}</span>
                    <span className="text-xs font-bold bg-brand-100 text-brand-800 px-2 py-0.5 rounded-full">{tr.role}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                    <p><span className="font-medium text-gray-400">NIN:</span> {tr.nin}</p>
                    <p><span className="font-medium text-gray-400">DOB:</span> {tr.dob}</p>
                    <p><span className="font-medium text-gray-400">Gender:</span> {tr.gender}</p>
                    <p><span className="font-medium text-gray-400">Occupation:</span> {tr.occupation}</p>
                    <p className="col-span-2"><span className="font-medium text-gray-400">Residential Address:</span> {tr.address}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Aims and Objectives */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <ListOrdered className="w-4 h-4 mr-1.5" /> Aims & Objectives (Section 5)
            </h4>
            <ul className="space-y-1.5 text-sm text-gray-800 font-medium">
              {ngo.aimsAndObjectives.map((aim, i) => (
                <li key={i} className="p-2 bg-gray-50 rounded-lg">{aim}</li>
              ))}
            </ul>
          </div>
        </div>
      );
    } else if (pkgType === 'corporate') {
      const corp = data.companyDetails;
      return (
        <div className="space-y-6">
          {/* Proposed Names & Objects */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <Briefcase className="w-4 h-4 mr-1.5" /> Proposed Names & Objects
            </h4>
            <div className="space-y-4">
              <div>
                <span className="text-xs text-gray-500 block">Proposed Corporate Names</span>
                <ol className="list-decimal pl-5 text-sm font-bold text-gray-900">
                  {corp.proposedNames.map((n, i) => n ? <li key={i}>{n}</li> : null)}
                </ol>
              </div>
              <div>
                <span className="text-xs text-gray-500 block">Objects of Memorandum</span>
                <ul className="space-y-1 text-sm font-semibold text-gray-800">
                  {corp.objectsOfMemorandum.map((obj, i) => <li key={i} className="p-2 bg-gray-50 rounded-lg">{obj}</li>)}
                </ul>
              </div>
            </div>
          </div>

          {/* Directors */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <User className="w-4 h-4 mr-1.5" /> Board of Directors ({corp.directors.length})
            </h4>
            <div className="space-y-4">
              {corp.directors.map((d, idx) => (
                <div key={d.id} className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-xs text-gray-700 space-y-2">
                  <p className="font-bold text-sm text-gray-900">{d.firstName} {d.otherName} {d.surname}</p>
                  <div className="grid grid-cols-2 gap-2">
                    <p><span className="text-gray-400">DOB:</span> {d.dob}</p>
                    <p><span className="text-gray-400">Gender:</span> {d.gender}</p>
                    <p><span className="text-gray-400">Nationality:</span> {d.nationality}</p>
                    <p><span className="text-gray-400">Phone:</span> {d.phone}</p>
                    <p><span className="text-gray-400">Email:</span> {d.email}</p>
                    <p><span className="text-gray-400">Identity:</span> {d.idType} ({d.idNumber})</p>
                    <p className="col-span-2"><span className="text-gray-400">Address:</span> {d.address.houseNumber} {d.address.streetName}, {d.address.city}, {d.address.lga}, {d.address.state} State</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Shareholders & Share Capital */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <Share2 className="w-4 h-4 mr-1.5" /> Shareholders & Share Capital
            </h4>
            <div className="mb-4 text-xs font-semibold text-gray-600 bg-brand-50 p-3 rounded-lg flex justify-between">
              <span>Total Shares: {corp.shareCapitalBreakdown.totalShares.toLocaleString()}</span>
              <span>Nominal Value: ₦{corp.shareCapitalBreakdown.nominalValue}</span>
            </div>
            <div className="space-y-3">
              {corp.shareholders.map((s, idx) => (
                <div key={s.id} className="flex justify-between items-center p-2.5 bg-gray-50 rounded-lg border border-gray-100 text-sm">
                  <div>
                    <span className="font-bold text-gray-900">{s.firstName} {s.surname}</span>
                    <span className="text-xs text-gray-400 block">{s.idType}: {s.idNumber}</span>
                  </div>
                  <span className="font-bold text-brand-700 bg-brand-50 px-2.5 py-1 rounded">{s.shares}% Shares</span>
                </div>
              ))}
            </div>
          </div>

          {/* Witness */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <ClipboardSignature className="w-4 h-4 mr-1.5" /> Witness Information
            </h4>
            <div className="text-sm">
              <p className="font-bold text-gray-900">{corp.witness.firstName} {corp.witness.otherName} {corp.witness.surname}</p>
              <p className="text-xs text-gray-500">{corp.witness.email} — {corp.witness.phone}</p>
              <p className="text-xs text-gray-600 mt-2">
                Address: {corp.witness.address.houseNumber} {corp.witness.address.streetName}, {corp.witness.address.city}, {corp.witness.address.lga}, {corp.witness.address.state} State
              </p>
            </div>
          </div>
        </div>
      );
    } else {
      // Enterprise Business Name / Standard
      const ent = data.enterpriseDetails;
      return (
        <div className="space-y-6">
          {/* Proposed Names */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <Briefcase className="w-4 h-4 mr-1.5" /> Proposed Business Names
            </h4>
            <ol className="list-decimal pl-5 text-sm font-bold text-gray-900 space-y-1">
              {ent.proposedNames.map((n, i) => n ? <li key={i}>{n}</li> : null)}
            </ol>
          </div>

          {/* Proprietor Details */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-3 pb-2 border-b border-gray-100 flex items-center">
              <User className="w-4 h-4 mr-1.5" /> Proprietor Personal Details
            </h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-xs text-gray-500 block">Full Name</span>
                <span className="font-bold text-gray-900">{ent.personalDetails.firstName} {ent.personalDetails.otherName} {ent.personalDetails.surname}</span>
              </div>
              <div>
                <span className="text-xs text-gray-500 block">DOB / Gender</span>
                <span className="font-semibold text-gray-900">{ent.personalDetails.dob} ({ent.personalDetails.gender})</span>
              </div>
              <div>
                <span className="text-xs text-gray-500 block">NIN Number</span>
                <span className="font-bold text-brand-800">{ent.personalDetails.nin}</span>
              </div>
              <div>
                <span className="text-xs text-gray-500 block">Phone & Email</span>
                <span className="font-semibold text-gray-900">{ent.personalDetails.phone} / {ent.personalDetails.email}</span>
              </div>
            </div>
          </div>

          {/* Dual Addresses */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm space-y-4">
            <div>
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1 pb-1 border-b border-gray-100 flex items-center">
                <MapPin className="w-3.5 h-3.5 mr-1" /> Residential (Home) Address
              </h4>
              <p className="text-sm font-semibold text-gray-800">
                {ent.homeAddress.houseNumber} {ent.homeAddress.streetName}, {ent.homeAddress.city}, {ent.homeAddress.lga}, {ent.homeAddress.state} State
              </p>
            </div>
            <div>
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1 pb-1 border-b border-gray-100 flex items-center">
                <Briefcase className="w-3.5 h-3.5 mr-1" /> Business Address
              </h4>
              <p className="text-sm font-semibold text-gray-800">
                {ent.businessAddress.houseNumber} {ent.businessAddress.streetName}, {ent.businessAddress.city}, {ent.businessAddress.lga}, {ent.businessAddress.state} State
              </p>
            </div>
          </div>

          {/* Nature of Business */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <h4 className="text-xs font-bold text-brand-600 uppercase tracking-wider mb-2 pb-1 border-b border-gray-100">
              Nature of Business
            </h4>
            <p className="text-sm font-medium text-gray-800 italic bg-gray-50 p-3 rounded-xl border border-gray-100">
              {ent.natureOfBusiness || 'No description provided.'}
            </p>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col overflow-hidden">
      <Header />
      
      <main className="flex-1 flex overflow-hidden">
        {/* Kanban Board */}
        <div className={`flex-1 overflow-x-auto p-6 ${selectedClient ? 'hidden lg:block' : 'block'}`}>
          <div className="flex items-center justify-between mb-8">
            <h1 className="heading-font text-2xl font-bold text-gray-900">Pipeline Board</h1>
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Search clients..." 
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none w-64" 
                />
              </div>
              <button className="p-2 border border-gray-200 rounded-lg bg-white text-gray-600 hover:bg-gray-50">
                <Filter className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex space-x-6 min-w-max pb-8">
            {stages.map(stage => (
              <div key={stage.id} className="w-80 flex flex-col max-h-full">
                <div className="flex items-center justify-between mb-4 px-1">
                  <h3 className="font-bold text-sm text-gray-700 uppercase tracking-wider">{stage.label}</h3>
                  <span className="text-xs font-bold text-gray-400 bg-gray-200 px-2 py-0.5 rounded-full">
                    {filteredClients.filter(c => c.status === stage.id).length}
                  </span>
                </div>
                <div className="flex-1 bg-gray-100/50 rounded-2xl p-3 min-h-[500px] overflow-y-auto space-y-3">
                  {filteredClients.filter(c => c.status === stage.id).map(client => {
                    const primaryName = client.intakeData.enterpriseDetails?.proposedNames?.[0] || 
                                        client.intakeData.companyDetails?.proposedNames?.[0] || 
                                        client.intakeData.ngoDetails?.proposedNames?.[0] || 
                                        client.email;
                    return (
                      <div 
                        key={client.id}
                        onClick={() => setSelectedClient(client)}
                        className={`bg-white p-4 rounded-xl shadow-sm border cursor-pointer transition-all hover:shadow-md ${selectedClient?.id === client.id ? 'border-brand-500 ring-1 ring-brand-500' : 'border-gray-200 hover:border-gray-300'}`}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <span className="text-[10px] font-extrabold text-brand-600 bg-brand-50 px-2 py-0.5 rounded-md uppercase tracking-wider">{client.package.type}</span>
                          <span className="text-[10px] text-gray-400 font-medium">{client.submittedAt}</span>
                        </div>
                        <p className="font-bold text-gray-900 truncate mb-1">{primaryName}</p>
                        <p className="text-xs text-gray-500 truncate mb-4">{client.email}</p>
                        
                        <div className="flex items-center justify-between">
                          <div className="w-full bg-gray-100 rounded-full h-1.5 mr-4">
                            <div className="bg-brand-500 h-1.5 rounded-full" style={{ width: `${client.progress}%` }}></div>
                          </div>
                          <span className="text-xs font-semibold text-gray-500">{client.progress}%</span>
                        </div>
                        
                        {client.actionNeeded && (
                          <div className="mt-3 pt-3 border-t border-gray-100 flex items-center text-xs text-red-600 font-bold animate-pulse">
                            <AlertCircle className="w-3.5 h-3.5 mr-1" /> Problem Flagged
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Client Detail View */}
        <AnimatePresence>
          {selectedClient && (
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="absolute inset-y-0 right-0 w-full lg:w-1/2 max-w-3xl bg-white shadow-2xl border-l border-gray-200 flex flex-col z-40 mt-16"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-white">
                <div className="flex items-center">
                  <button onClick={() => setSelectedClient(null)} className="lg:hidden p-2 mr-2 text-gray-500 hover:bg-gray-100 rounded-lg">
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                  <div>
                    <h2 className="heading-font font-bold text-lg text-gray-900">
                      {selectedClient.intakeData.enterpriseDetails?.proposedNames?.[0] || 
                       selectedClient.intakeData.companyDetails?.proposedNames?.[0] || 
                       selectedClient.intakeData.ngoDetails?.proposedNames?.[0] || 
                       'New Onboarding'}
                    </h2>
                    <p className="text-xs text-gray-500">{selectedClient.email} • {selectedClient.package.name}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button onClick={() => setShowFlagModal(true)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-100" title="Flag Issue">
                    <MessageSquareWarning className="w-5 h-5" />
                  </button>
                  <button onClick={handleCopyData} className="flex items-center px-4 py-2 bg-gray-900 text-white text-xs font-bold rounded-xl hover:bg-gray-800 transition-colors shadow-sm uppercase tracking-wide">
                    <Copy className="w-4 h-4 mr-1.5" /> Smart Copy
                  </button>
                </div>
              </div>

              {selectedClient.actionNeeded && (
                <div className="px-6 py-3 bg-red-50 border-b border-red-100 flex items-center justify-between">
                  <div className="flex items-center text-red-700 text-xs">
                    <AlertCircle className="w-4 h-4 mr-2 shrink-0" />
                    <span className="font-bold mr-2">Client Problem Flag:</span> {selectedClient.actionNeeded}
                  </div>
                  <button onClick={() => updateClient(selectedClient.id, { actionNeeded: null })} className="text-xs font-bold text-red-600 hover:text-red-800 underline">
                    Resolve Flag
                  </button>
                </div>
              )}

              {/* Verified ID Smart Badge */}
              {selectedClient.intakeData.idScanCompleted && (
                <div className="px-6 py-2.5 bg-green-50 border-b border-green-100 flex items-center justify-between">
                  <div className="flex items-center text-green-800 text-xs font-semibold">
                    <CheckCircle2 className="w-4 h-4 mr-1.5 text-green-600" />
                    AI ID Scan Gateway Complete: National ID Verified
                  </div>
                  <span className="text-[10px] bg-green-200 text-green-900 px-2 py-0.5 rounded font-extrabold">{selectedClient.intakeData.scannedIdName || 'ID_NIN_CARD.pdf'}</span>
                </div>
              )}

              <div className="flex-1 overflow-y-auto bg-gray-50 p-6">
                
                {/* Dynamically Loaded CAC Detail Forms */}
                {renderClientDetailContent(selectedClient)}

                {/* Status Control Footer in Details */}
                <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm mt-6">
                   <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4 border-b border-gray-100 pb-2">Modify Client Stage</h3>
                   <div className="flex space-x-3">
                     <select 
                       value={selectedClient.status}
                       onChange={(e) => moveClient(selectedClient.id, e.target.value as any)}
                       className="flex-1 px-4 py-2 border border-gray-200 rounded-lg text-sm font-semibold text-gray-900 outline-none focus:ring-2 focus:ring-brand-500"
                     >
                       {stages.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
                     </select>
                     <button 
                       onClick={() => setSelectedClient(null)} 
                       className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-bold rounded-lg"
                     >
                       Close Details
                     </button>
                   </div>
                </div>

              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Flag Modal */}
        {showFlagModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/40 backdrop-blur-sm animate-fade-in">
            <div className="bg-white rounded-2xl shadow-xl border border-gray-100 w-full max-w-md p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-2 heading-font">Flag Regulatory Problem</h3>
              <p className="text-xs text-gray-500 mb-4">Explain to the client exactly what needs to be fixed. The wizard will show this alert to the client.</p>
              <textarea 
                rows={3}
                value={flagText}
                onChange={e => setFlagText(e.target.value)}
                placeholder="e.g. Your first choice name is unavailable. Please choose another prefix name."
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 outline-none resize-none mb-4 text-sm"
              />
              <div className="flex space-x-3 justify-end">
                <button onClick={() => setShowFlagModal(false)} className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-lg">Cancel</button>
                <button onClick={handleSendFlag} className="px-4 py-2 text-sm font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-sm">Send Flag to Client</button>
              </div>
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
