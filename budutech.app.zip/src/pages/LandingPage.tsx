import { ArrowRight, ShieldCheck, FileText, Briefcase, Zap, Building, HeartHandshake, MessageCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppStore, Package } from '../store';
import Header from '../components/Header';
import { motion } from 'motion/react';

const packages: Package[] = [
  {
    id: 'enterprise',
    name: 'Business Name',
    price: 35000,
    type: 'enterprise',
    features: ['Name Reservation', 'Full Sole Proprietorship filing', 'TIN Generation', 'Digital Certificate']
  },
  {
    id: 'corporate',
    name: 'Corporate LLC',
    price: 120000,
    type: 'corporate',
    features: ['Name Reservation', 'Limited Liability Company setup', 'TIN & VAT Registration', 'Shareholder Structure', 'Corporate Seals Design']
  },
  {
    id: 'ngo',
    name: 'NGO / Foundation',
    price: 200000,
    type: 'ngo',
    features: ['Trustee Appointment Filing', 'Newspaper Publication', 'Constitutional Drafting', 'CAC Certificate', 'SCUML Registration Support']
  },
  {
    id: 'upgrade',
    name: 'Corporate Upgrade',
    price: 80000,
    type: 'upgrade',
    features: ['Enterprise to LLC Conversion', 'Status Report Update', 'Post-incorporation filing']
  }
];

export default function LandingPage() {
  const navigate = useNavigate();
  const { setSelectedPackage } = useAppStore();

  const handleSelectPackage = (pkg: Package) => {
    setSelectedPackage(pkg);
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden pt-24 pb-32 lg:pt-32 lg:pb-40">
          <div className="absolute inset-0 bg-brand-50/50 -z-10" />
          <div className="absolute inset-y-0 right-0 w-1/2 bg-gradient-to-l from-brand-100/40 to-transparent -z-10" />
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:grid lg:grid-cols-12 lg:gap-16 items-center">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="lg:col-span-6 text-center lg:text-left"
              >
                <h1 className="heading-font text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight text-gray-900 mb-6">
                  Launch, Formalize, and <span className="text-brand-600">Scale</span> Your Business Today.
                </h1>
                <p className="text-xl text-gray-600 mb-10 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
                  Skip the registry headache. Register your company, enterprise, or NGO through a seamless, automated portal built for modern entrepreneurs.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start space-y-4 sm:space-y-0 sm:space-x-4">
                  <a href="#pricing" className="w-full sm:w-auto px-8 py-4 bg-brand-600 hover:bg-brand-500 text-white rounded-full font-medium text-lg transition-all shadow-lg hover:shadow-xl flex items-center justify-center">
                    Get Started <ArrowRight className="ml-2 w-5 h-5" />
                  </a>
                  <a href="#how-it-works" className="w-full sm:w-auto px-8 py-4 bg-white text-gray-900 border border-gray-200 hover:border-gray-300 rounded-full font-medium text-lg transition-all flex items-center justify-center">
                    Learn More
                  </a>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="lg:col-span-6 mt-16 lg:mt-0 relative"
              >
                <div className="relative rounded-2xl bg-white shadow-2xl border border-gray-100 p-8 overflow-hidden">
                  <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-brand-400 to-brand-600" />
                  <div className="flex items-center justify-between mb-8">
                    <div>
                      <h3 className="heading-font font-bold text-xl">BuduFlow Application</h3>
                      <p className="text-sm text-gray-500">Acme Global Services</p>
                    </div>
                    <span className="inline-flex items-center rounded-full bg-blue-50 px-3 py-1 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-700/10">
                      In Review
                    </span>
                  </div>
                  
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center justify-between text-sm font-medium mb-2">
                        <span className="text-brand-600">Step 2 of 4</span>
                        <span className="text-gray-500">50% Complete</span>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-2">
                        <div className="bg-brand-500 h-2 rounded-full" style={{ width: '50%' }}></div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex items-center p-4 bg-gray-50 rounded-xl border border-gray-100">
                        <ShieldCheck className="w-5 h-5 text-brand-500 mr-3" />
                        <span className="text-sm font-medium">Name Availability Search</span>
                        <span className="ml-auto text-xs text-brand-600 font-bold">DONE</span>
                      </div>
                      <div className="flex items-center p-4 bg-white rounded-xl border border-brand-200 shadow-sm ring-1 ring-brand-500/10">
                        <FileText className="w-5 h-5 text-brand-500 mr-3" />
                        <span className="text-sm font-medium text-brand-900">Documentation Review</span>
                        <span className="ml-auto flex h-2 w-2 relative">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
                        </span>
                      </div>
                      <div className="flex items-center p-4 bg-gray-50 rounded-xl border border-gray-100 opacity-50">
                        <Briefcase className="w-5 h-5 text-gray-400 mr-3" />
                        <span className="text-sm font-medium">Filed with Registry</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Decorative blobs */}
                <div className="absolute -top-12 -right-12 w-32 h-32 bg-brand-100 rounded-full blur-3xl -z-10" />
                <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-brand-200 rounded-full blur-3xl -z-10" />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Services Grid */}
        <section id="services" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="heading-font text-3xl font-bold text-gray-900 mb-4">Comprehensive Corporate Services</h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">Everything you need to legally structure and formalize your business identity.</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { icon: <Building className="w-6 h-6" />, title: "Corporate Registration", desc: "Limited liability companies (includes name reservation and full filling)." },
                { icon: <Briefcase className="w-6 h-6" />, title: "Business Name", desc: "Structured sole proprietorships and small business setups." },
                { icon: <HeartHandshake className="w-6 h-6" />, title: "NGO & Association", desc: "Specialized onboarding for non-profits, foundations, and clubs." },
                { icon: <Zap className="w-6 h-6" />, title: "Corporate Upgrades", desc: "Upgrading existing enterprises to limited companies alongside post-incorporation tasks." }
              ].map((service, idx) => (
                <div key={idx} className="p-8 rounded-2xl bg-gray-50 hover:bg-white hover:shadow-xl hover:shadow-brand-500/5 transition-all border border-transparent hover:border-gray-100">
                  <div className="w-12 h-12 bg-brand-100 text-brand-600 rounded-xl flex items-center justify-center mb-6">
                    {service.icon}
                  </div>
                  <h3 className="font-bold text-xl mb-3 heading-font">{service.title}</h3>
                  <p className="text-gray-600 leading-relaxed text-sm">{service.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Workspace */}
        <section id="pricing" className="py-24 bg-gray-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="heading-font text-3xl md:text-4xl font-bold mb-4">Transparent Pricing, Zero Surprises</h2>
              <p className="text-lg text-gray-400 max-w-2xl mx-auto">Choose the package that fits your business structure and begin your secure application instantly.</p>
            </div>
            
            <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">
              {packages.map((pkg) => (
                <div key={pkg.id} className="bg-gray-800 rounded-2xl p-8 border border-gray-700 flex flex-col hover:border-brand-500 transition-colors relative">
                  {pkg.type === 'corporate' && (
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-brand-500 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                      Most Popular
                    </div>
                  )}
                  <h3 className="heading-font text-2xl font-bold mb-2">{pkg.name}</h3>
                  <div className="mb-6">
                    <span className="text-4xl font-bold">₦{pkg.price.toLocaleString()}</span>
                  </div>
                  <ul className="space-y-4 mb-8 flex-1">
                    {pkg.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start">
                        <ShieldCheck className="w-5 h-5 text-brand-400 mr-3 shrink-0" />
                        <span className="text-sm text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <button 
                    onClick={() => handleSelectPackage(pkg)}
                    className={`w-full py-3 px-4 rounded-xl font-medium transition-all ${
                      pkg.type === 'corporate' 
                        ? 'bg-brand-500 hover:bg-brand-400 text-white shadow-lg shadow-brand-500/25' 
                        : 'bg-white text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    Select Package
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Lead Capture */}
        <section className="py-24 bg-white border-b border-gray-100">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="heading-font text-3xl font-bold text-gray-900 mb-4">Not Sure Which Package Fits Your Business?</h2>
            <p className="text-gray-600 mb-10">Our corporate consultants are ready to advise you on the best structure for your goals.</p>
            
            <form className="space-y-4 text-left" onSubmit={(e) => { e.preventDefault(); alert("Inquiry submitted successfully!"); }}>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                  <input type="text" required className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all" placeholder="Jane Doe" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                  <input type="email" required className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all" placeholder="jane@example.com" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                <input type="tel" required className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all" placeholder="+234..." />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">How can we help?</label>
                <textarea rows={4} required className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all resize-none" placeholder="I want to register a tech startup but I'm not sure if..." />
              </div>
              <button type="submit" className="w-full py-4 bg-gray-900 text-white rounded-xl font-medium hover:bg-gray-800 transition-colors">
                Send Inquiry
              </button>
            </form>
          </div>
        </section>
      </main>
      
      <footer className="bg-gray-50 py-12 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center space-x-2 mb-4 md:mb-0">
            <div className="w-6 h-6 bg-gray-900 rounded flex items-center justify-center">
              <span className="text-white font-bold text-sm">B</span>
            </div>
            <span className="font-bold text-gray-900">BuduTech Services</span>
          </div>
          <p className="text-sm text-gray-500">© 2026 BuduTech Digital Services. All rights reserved.</p>
        </div>
      </footer>

      {/* Floating WhatsApp Contact Widget */}
      <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3">
        <div className="bg-white px-4 py-2 rounded-2xl shadow-lg border border-gray-100 hidden sm:block animate-pulse">
          <p className="text-sm font-medium text-gray-800">Need help? Chat with us!</p>
        </div>
        <a
          href="https://wa.me/2349027591229?text=Hello%20BuduTech,%20I%20would%20like%20to%20make%20an%20inquiry%20about%20your%20registration%20packages."
          target="_blank"
          rel="noopener noreferrer"
          className="w-14 h-14 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-full flex items-center justify-center shadow-xl shadow-[#25D366]/30 transition-transform hover:scale-110 active:scale-95"
        >
          <MessageCircle className="w-7 h-7" />
        </a>
      </div>
    </div>
  );
}
