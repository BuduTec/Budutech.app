import { useState, useRef, useEffect } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { useAppStore, initialIntakeData, Trustee, DirectorShareholder } from '../store';
import Header from '../components/Header';
import { 
  ArrowLeft, ArrowRight, CheckCircle2, UploadCloud, Eraser, AlertCircle, 
  Sparkles, Camera, Plus, Trash2, FileText, Check, ShieldCheck, UserCheck, HelpCircle 
} from 'lucide-react';
import SignatureCanvas from 'react-signature-canvas';
import { motion, AnimatePresence } from 'motion/react';

export default function IntakeFormPage() {
  const { 
    user, 
    selectedPackage, 
    intakeData, 
    updateIntakeData, 
    setApplicationStatus,
    setActionNeeded,
    clients,
    addClient
  } = useAppStore();
  const navigate = useNavigate();

  const [currentStep, setCurrentStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [scanStatus, setScanStatus] = useState<'idle' | 'scanning' | 'review' | 'completed'>('idle');
  const [scanProgress, setScanProgress] = useState(0);
  const [ocrTempData, setOcrTempData] = useState<any>(null);

  // States for dynamic inputs
  const [tempObject, setTempObject] = useState('');
  const [tempObjective, setTempObjective] = useState('');

  const sigCanvas = useRef<SignatureCanvas>(null);
  const witnessSigCanvas = useRef<SignatureCanvas>(null);

  if (!user || !selectedPackage) return <Navigate to="/" replace />;

  const isNGO = selectedPackage.type === 'ngo';
  const isCorporate = selectedPackage.type === 'corporate';
  const isEnterprise = selectedPackage.type === 'enterprise' || selectedPackage.type === 'upgrade';

  // Step definitions based on chosen package type
  const getSteps = () => {
    if (isNGO) {
      return [
        { id: 'smart-scan', title: 'Fast-Track ID Scan' },
        { id: 'ngo-rep', title: 'Section 1: Authorized Rep' },
        { id: 'ngo-names', title: 'Section 2: Names & Mission' },
        { id: 'ngo-address', title: 'Section 3: Registered Office' },
        { id: 'ngo-trustees', title: 'Section 4: Board of Trustees' },
        { id: 'ngo-aims', title: 'Section 5: Aims & Objectives' },
        { id: 'ngo-review', title: 'Section 6: Consultant Review' },
      ];
    } else if (isCorporate) {
      return [
        { id: 'smart-scan', title: 'Fast-Track ID Scan' },
        { id: 'names-objects', title: 'Proposed Names & Objects' },
        { id: 'personal-ocr', title: 'Primary Applicant Details' },
        { id: 'directors', title: 'Director Information' },
        { id: 'shareholders', title: 'Shareholder Information' },
        { id: 'share-capital', title: 'Share Capital Breakdown' },
        { id: 'corp-witness', title: 'Witness Details' },
        { id: 'corp-docs', title: 'Signature & Files' },
      ];
    } else {
      // Enterprise / Business Name
      return [
        { id: 'smart-scan', title: 'Fast-Track ID Scan' },
        { id: 'ent-names', title: 'Proposed Business Names' },
        { id: 'ent-personal', title: 'Personal Details' },
        { id: 'ent-addresses', title: 'Addresses Setup' },
        { id: 'ent-nature', title: 'Business Nature' },
        { id: 'ent-docs', title: 'Supporting Files' },
      ];
    }
  };

  const steps = getSteps();

  // Reset or fill defaults if empty
  useEffect(() => {
    // Make sure we have at least 1 director / shareholder if blank initially
    if (isCorporate) {
      if (intakeData.companyDetails.directors.length === 0) {
        updateIntakeData({
          companyDetails: {
            ...intakeData.companyDetails,
            directors: [{
              id: 'dir-initial',
              surname: '',
              firstName: '',
              otherName: '',
              dob: '',
              gender: '',
              nationality: 'Nigerian',
              phone: '',
              email: '',
              address: { state: '', lga: '', city: '', houseNumber: '', streetName: '' },
              idType: 'NIN',
              idNumber: '',
            }],
            shareholders: [{
              id: 'sh-initial',
              surname: '',
              firstName: '',
              otherName: '',
              dob: '',
              gender: '',
              nationality: 'Nigerian',
              phone: '',
              email: '',
              address: { state: '', lga: '', city: '', houseNumber: '', streetName: '' },
              idType: 'NIN',
              idNumber: '',
              shares: 100,
            }],
          }
        });
      }
    }
    if (isNGO) {
      if (intakeData.ngoDetails.trustees.length === 0) {
        updateIntakeData({
          ngoDetails: {
            ...intakeData.ngoDetails,
            trustees: [
              {
                id: 'trust-1',
                fullName: '',
                role: 'Chairman',
                nin: '',
                dob: '',
                gender: '',
                occupation: '',
                address: '',
              },
              {
                id: 'trust-2',
                fullName: '',
                role: 'Secretary',
                nin: '',
                dob: '',
                gender: '',
                occupation: '',
                address: '',
              }
            ],
          }
        });
      }
    }
  }, [selectedPackage]);

  const handleIdUploadSimulate = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    
    if (file.size > 5 * 1024 * 1024) {
      alert("Security Block: File size exceeds 5MB limit.");
      return;
    }
    if (!file.type.match(/image\/(jpeg|png|jpg)|application\/pdf/)) {
      alert("Security Block: Invalid file type. Only standard images and PDFs are allowed.");
      return;
    }
    
    setScanStatus('scanning');
    setScanProgress(10);
    setError(null);

    const interval = setInterval(() => {
      setScanProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          return 100;
        }
        return p + 15;
      });
    }, 300);

    setTimeout(() => {
      setScanStatus('review');
      
      const ocrExtracted = {
        fileName: file.name,
        firstName: 'Emmanuel',
        surname: 'Elubuduka',
        otherName: 'Kaene',
        dob: '1995-07-04',
        gender: 'Male',
        phone: '08149204958',
        email: user.email,
        nin: '29485710294',
      };
      setOcrTempData(ocrExtracted);
    }, 2400);
  };

  const handleAcceptOcr = () => {
    if (!ocrTempData) return;
    setScanStatus('completed');

    if (isEnterprise) {
      updateIntakeData({
        idScanCompleted: true,
        scannedIdName: ocrTempData.fileName,
        enterpriseDetails: {
          ...intakeData.enterpriseDetails,
          personalDetails: {
            ...intakeData.enterpriseDetails.personalDetails,
            ...ocrTempData
          }
        }
      });
    } else if (isCorporate) {
      updateIntakeData({
        idScanCompleted: true,
        scannedIdName: ocrTempData.fileName,
        enterpriseDetails: {
          ...intakeData.enterpriseDetails,
          personalDetails: {
            ...intakeData.enterpriseDetails.personalDetails,
            ...ocrTempData
          }
        },
        companyDetails: {
          ...intakeData.companyDetails,
          directors: intakeData.companyDetails.directors.map((d, idx) => 
            idx === 0 ? {
              ...d,
              firstName: ocrTempData.firstName,
              surname: ocrTempData.surname,
              otherName: ocrTempData.otherName,
              dob: ocrTempData.dob,
              gender: ocrTempData.gender,
              phone: ocrTempData.phone,
              email: ocrTempData.email,
              idNumber: ocrTempData.nin,
            } : d
          ),
          shareholders: intakeData.companyDetails.shareholders.map((s, idx) => 
            idx === 0 ? {
              ...s,
              firstName: ocrTempData.firstName,
              surname: ocrTempData.surname,
              otherName: ocrTempData.otherName,
              dob: ocrTempData.dob,
              gender: ocrTempData.gender,
              phone: ocrTempData.phone,
              email: ocrTempData.email,
              idNumber: ocrTempData.nin,
            } : s
          )
        }
      });
    } else if (isNGO) {
      updateIntakeData({
        idScanCompleted: true,
        scannedIdName: ocrTempData.fileName,
        ngoDetails: {
          ...intakeData.ngoDetails,
          representative: {
            ...intakeData.ngoDetails.representative,
            firstName: ocrTempData.firstName,
            surname: ocrTempData.surname,
            otherName: ocrTempData.otherName,
            dob: ocrTempData.dob,
            gender: ocrTempData.gender,
            phone: ocrTempData.phone,
            email: ocrTempData.email,
            occupation: 'Business Executive'
          },
          trustees: intakeData.ngoDetails.trustees.map((t, idx) => 
            idx === 0 ? {
              ...t,
              fullName: `${ocrTempData.firstName} ${ocrTempData.otherName} ${ocrTempData.surname}`,
              nin: ocrTempData.nin,
              dob: ocrTempData.dob,
              gender: ocrTempData.gender,
            } : t
          )
        }
      });
    }
  };

  const handleGenericFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    
    if (file.size > 5 * 1024 * 1024) {
      alert("Security Block: File size exceeds 5MB limit.");
      return;
    }
    if (!file.type.match(/image\/(jpeg|png|jpg)|application\/pdf/)) {
      alert("Security Block: Invalid file type. Only standard images and PDFs are allowed.");
      return;
    }
    alert(`Security Check Passed. ${file.name} securely attached.`);
  };

  const handleNext = () => {
    setError(null);
    const stepId = steps[currentStep].id;

    // --- Validation Logic ---
    if (stepId === 'smart-scan') {
      if (!intakeData.idScanCompleted) {
        setError('Please upload your primary ID to proceed, or use the simulated smart-fill scan.');
        return;
      }
    }

    if (stepId === 'ent-names') {
      const { proposedNames } = intakeData.enterpriseDetails;
      if (!proposedNames[0] || !proposedNames[1]) {
        setError('Please provide both Business Name 1 and Business Name 2 options.');
        return;
      }
    }

    if (stepId === 'ent-personal') {
      const { surname, firstName, dob, gender, phone, email, nin } = intakeData.enterpriseDetails.personalDetails;
      if (!surname || !firstName || !dob || !gender || !phone || !email || !nin) {
        setError('Please complete all required personal details fields.');
        return;
      }
    }

    if (stepId === 'ent-addresses') {
      const { homeAddress, businessAddress } = intakeData.enterpriseDetails;
      if (!homeAddress.state || !homeAddress.lga || !homeAddress.city || !homeAddress.streetName ||
          !businessAddress.state || !businessAddress.lga || !businessAddress.city || !businessAddress.streetName) {
        setError('Both Home Address and Business Address require State, LGA, City, and Street Name.');
        return;
      }
    }

    if (stepId === 'ent-nature') {
      if (!intakeData.enterpriseDetails.natureOfBusiness) {
        setError('Please specify the Nature of Business.');
        return;
      }
    }

    if (stepId === 'names-objects') {
      const { proposedNames, objectsOfMemorandum } = intakeData.companyDetails;
      if (!proposedNames[0] || !proposedNames[1]) {
        setError('Please provide both Company Name 1 and Company Name 2.');
        return;
      }
      if (objectsOfMemorandum.length === 0) {
        setError('Please add at least one business object to the memorandum.');
        return;
      }
    }

    if (stepId === 'directors') {
      const { directors } = intakeData.companyDetails;
      if (directors.length === 0) {
        setError('Please add at least one director.');
        return;
      }
      const invalid = directors.some(d => !d.firstName || !d.surname || !d.dob || !d.email || !d.phone || !d.address.state || !d.idNumber);
      if (invalid) {
        setError('Please fill in all details (including address and ID) for all listed directors.');
        return;
      }
    }

    if (stepId === 'shareholders') {
      const { shareholders } = intakeData.companyDetails;
      if (shareholders.length === 0) {
        setError('Please add at least one shareholder.');
        return;
      }
      const invalid = shareholders.some(s => !s.firstName || !s.surname || !s.dob || !s.email || !s.phone || !s.address.state || !s.idNumber);
      if (invalid) {
        setError('Please fill in all details for all listed shareholders.');
        return;
      }
    }

    if (stepId === 'share-capital') {
      const { shareholders } = intakeData.companyDetails;
      const totalShares = shareholders.reduce((sum, s) => sum + (Number(s.shares) || 0), 0);
      if (totalShares !== 100) {
        setError(`Total sharing percentage must equal exactly 100%. Current sum: ${totalShares}%.`);
        return;
      }
    }

    if (stepId === 'corp-witness') {
      const { witness } = intakeData.companyDetails;
      if (!witness.firstName || !witness.surname || !witness.phone || !witness.email || !witness.address.state || !witness.address.streetName) {
        setError('Please complete all Witness details.');
        return;
      }
    }

    // NGO Validation
    if (stepId === 'ngo-rep') {
      const { surname, firstName, dob, gender, phone, email, occupation } = intakeData.ngoDetails.representative;
      if (!surname || !firstName || !dob || !gender || !phone || !email || !occupation) {
        setError('Please complete all Representative personal details fields.');
        return;
      }
    }

    if (stepId === 'ngo-names') {
      const { proposedNames, mission } = intakeData.ngoDetails;
      if (!proposedNames[0] || !proposedNames[1] || !proposedNames[2]) {
        setError('The CAC requires three name options in order of preference.');
        return;
      }
      if (!mission.trim()) {
        setError('Please provide a short summary organization mission statement.');
        return;
      }
    }

    if (stepId === 'ngo-address') {
      const { officeAddress, utilityBillUrl } = intakeData.ngoDetails;
      if (!officeAddress.houseNumber || !officeAddress.streetName || !officeAddress.city || !officeAddress.lga || !officeAddress.state) {
        setError('Please complete the office address fields.');
        return;
      }
    }

    if (stepId === 'ngo-trustees') {
      const { trustees } = intakeData.ngoDetails;
      if (trustees.length < 2) {
        setError('Under Nigerian law, you must have a minimum of two (2) trustees.');
        return;
      }
      
      const hasChairman = trustees.some(t => t.role.toLowerCase() === 'chairman');
      const hasSecretary = trustees.some(t => t.role.toLowerCase() === 'secretary');
      
      if (!hasChairman || !hasSecretary) {
        setError('You must designate at least one Chairman and one Secretary among your trustees.');
        return;
      }

      const invalid = trustees.some(t => !t.fullName || !t.dob || !t.nin || !t.occupation || !t.address);
      if (invalid) {
        setError('Please fill out all fields for all Board of Trustees.');
        return;
      }
    }

    if (stepId === 'ngo-aims') {
      const { aimsAndObjectives } = intakeData.ngoDetails;
      if (aimsAndObjectives.length === 0) {
        setError('Please add at least one aim and objective.');
        return;
      }
    }

    if (currentStep < steps.length - 1) {
      setCurrentStep(s => s + 1);
    } else {
      // Data Safety & Anti-Tamper Check: Re-run global validation before final save
      if (isCorporate) {
        const totalShares = intakeData.companyDetails.shareholders.reduce((sum, s) => sum + (Number(s.shares) || 0), 0);
        if (totalShares !== 100) {
          setError(`Security Block: Tampering detected. Shareholder sum must equal exactly 100%.`);
          return;
        }
        if (intakeData.companyDetails.directors.length === 0 || intakeData.companyDetails.shareholders.length === 0) {
          setError(`Security Block: Missing essential corporate data.`);
          return;
        }
        if (!intakeData.companyDetails.proposedNames[0] || !intakeData.companyDetails.proposedNames[1]) {
          setError(`Security Block: Missing proposed names.`);
          return;
        }
      } else if (isNGO) {
        if (intakeData.ngoDetails.trustees.length < 2) {
          setError('Security Block: Tampering detected. Minimum of two (2) trustees required.');
          return;
        }
        if (!intakeData.ngoDetails.proposedNames[0] || !intakeData.ngoDetails.proposedNames[1] || !intakeData.ngoDetails.proposedNames[2]) {
          setError('Security Block: Missing proposed names.');
          return;
        }
      } else if (isEnterprise) {
        if (!intakeData.enterpriseDetails.proposedNames[0] || !intakeData.enterpriseDetails.proposedNames[1]) {
          setError('Security Block: Missing proposed names.');
          return;
        }
      }

      // Create new client record & update applicationStatus
      const newProfile = {
        id: `client-${Date.now()}`,
        email: user.email,
        package: selectedPackage,
        status: 'review' as const,
        progress: 100,
        actionNeeded: null,
        submittedAt: new Date().toISOString().split('T')[0],
        intakeData: intakeData,
      };

      addClient(newProfile);
      setApplicationStatus('review');
      setActionNeeded(null);
      navigate('/dashboard');
    }
  };

  const handleBack = () => {
    setError(null);
    setCurrentStep(s => Math.max(0, s - 1));
  };

  const clearSignatureCanvas = (canvasRef: React.RefObject<SignatureCanvas | null>, fieldName: 'ninSlipUrl' | 'signatureUrl' | 'witnessSig') => {
    canvasRef.current?.clear();
    if (fieldName === 'signatureUrl') {
      updateIntakeData({
        enterpriseDetails: {
          ...intakeData.enterpriseDetails,
          documents: { ...intakeData.enterpriseDetails.documents, signatureUrl: undefined }
        }
      });
    }
  };

  const saveSignatureCanvas = (canvasRef: React.RefObject<SignatureCanvas | null>, fieldName: 'signatureUrl' | 'witnessSig') => {
    if (canvasRef.current?.isEmpty()) {
      setError('Please sign the pad first.');
      return;
    }
    const dataUrl = canvasRef.current?.getTrimmedCanvas().toDataURL('image/png');
    if (fieldName === 'signatureUrl') {
      updateIntakeData({
        enterpriseDetails: {
          ...intakeData.enterpriseDetails,
          documents: { ...intakeData.enterpriseDetails.documents, signatureUrl: dataUrl }
        }
      });
      alert('Signature Saved successfully.');
    }
  };

  const addMemorandumObject = () => {
    if (!tempObject.trim()) return;
    const currentList = intakeData.companyDetails.objectsOfMemorandum;
    const itemNum = currentList.length + 1;
    updateIntakeData({
      companyDetails: {
        ...intakeData.companyDetails,
        objectsOfMemorandum: [...currentList, `${itemNum}. ${tempObject.trim()}`]
      }
    });
    setTempObject('');
  };

  const removeMemorandumObject = (idx: number) => {
    const list = intakeData.companyDetails.objectsOfMemorandum.filter((_, i) => i !== idx)
      .map((item, i) => `${i + 1}. ${item.replace(/^\d+\.\s*/, '')}`);
    updateIntakeData({
      companyDetails: {
        ...intakeData.companyDetails,
        objectsOfMemorandum: list
      }
    });
  };

  const addNgoObjective = () => {
    if (!tempObjective.trim()) return;
    const currentList = intakeData.ngoDetails.aimsAndObjectives;
    const itemNum = currentList.length + 1;
    updateIntakeData({
      ngoDetails: {
        ...intakeData.ngoDetails,
        aimsAndObjectives: [...currentList, `${itemNum}. ${tempObjective.trim()}`]
      }
    });
    setTempObjective('');
  };

  const removeNgoObjective = (idx: number) => {
    const list = intakeData.ngoDetails.aimsAndObjectives.filter((_, i) => i !== idx)
      .map((item, i) => `${i + 1}. ${item.replace(/^\d+\.\s*/, '')}`);
    updateIntakeData({
      ngoDetails: {
        ...intakeData.ngoDetails,
        aimsAndObjectives: list
      }
    });
  };

  const renderStepContent = () => {
    const stepId = steps[currentStep].id;

    // STEP 0: SMART SCAN
    if (stepId === 'smart-scan') {
      return (
        <div className="space-y-6 text-center py-4">
          <div className="max-w-md mx-auto">
            <div className="w-16 h-16 bg-brand-100 text-brand-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="heading-font text-2xl font-bold text-gray-900 mb-2">Fast-Track Your Application</h3>
            <p className="text-gray-600 text-sm mb-8">
              Upload your Nigerian National ID Slip (NIN), driver's license, or passport. Our AI system will extract your key regulatory details instantly.
            </p>

            {scanStatus === 'scanning' ? (
              <div className="bg-brand-50 rounded-2xl p-8 border border-brand-100 mb-6">
                <div className="relative w-16 h-16 mx-auto mb-4">
                  <div className="absolute inset-0 rounded-full border-4 border-brand-200" />
                  <div className="absolute inset-0 rounded-full border-4 border-brand-500 border-t-transparent animate-spin" />
                </div>
                <p className="font-bold text-brand-800 text-sm animate-pulse">Scanning ID & Extracting Details...</p>
                <div className="w-full bg-brand-100 rounded-full h-2 mt-4 max-w-xs mx-auto overflow-hidden">
                  <div className="bg-brand-500 h-2 rounded-full transition-all duration-300" style={{ width: `${scanProgress}%` }} />
                </div>
              </div>
            ) : scanStatus === 'review' && ocrTempData ? (
              <div className="bg-white rounded-2xl p-8 border border-gray-200 mb-6 text-left shadow-sm">
                <h4 className="font-bold text-gray-900 mb-4 flex items-center">
                  <UserCheck className="w-5 h-5 mr-2 text-brand-600" /> Review Your Details
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-500">First Name</label>
                    <input type="text" value={ocrTempData.firstName} onChange={e => setOcrTempData({...ocrTempData, firstName: e.target.value})} className="w-full mt-1 px-3 py-2 border rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500">Surname</label>
                    <input type="text" value={ocrTempData.surname} onChange={e => setOcrTempData({...ocrTempData, surname: e.target.value})} className="w-full mt-1 px-3 py-2 border rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500">Other Name</label>
                    <input type="text" value={ocrTempData.otherName} onChange={e => setOcrTempData({...ocrTempData, otherName: e.target.value})} className="w-full mt-1 px-3 py-2 border rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500">Date of Birth</label>
                    <input type="date" value={ocrTempData.dob} onChange={e => setOcrTempData({...ocrTempData, dob: e.target.value})} className="w-full mt-1 px-3 py-2 border rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500">Gender</label>
                    <input type="text" value={ocrTempData.gender} onChange={e => setOcrTempData({...ocrTempData, gender: e.target.value})} className="w-full mt-1 px-3 py-2 border rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500">Phone Number</label>
                    <input type="tel" value={ocrTempData.phone} onChange={e => setOcrTempData({...ocrTempData, phone: e.target.value})} className="w-full mt-1 px-3 py-2 border rounded-lg text-sm" />
                  </div>
                </div>
                <div className="mt-6 flex justify-end">
                  <button type="button" onClick={handleAcceptOcr} className="px-6 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold shadow-md hover:bg-brand-700 transition">
                    Accept & Continue
                  </button>
                </div>
              </div>
            ) : intakeData.idScanCompleted ? (
              <div className="bg-green-50 rounded-2xl p-8 border border-green-100 mb-6 flex flex-col items-center">
                <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-3">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <p className="font-bold text-green-800 text-sm">NIN Scanned & Verified Successfully!</p>
                <p className="text-xs text-green-600 mt-1">{intakeData.scannedIdName}</p>
                <p className="text-xs text-gray-400 mt-3 italic">OCR Auto-populated First Name, Surname, DOB, and Gender fields.</p>
                
                <label className="mt-6 inline-flex items-center px-4 py-2 bg-white hover:bg-gray-50 text-gray-700 text-xs font-semibold rounded-xl border border-gray-200 transition-colors cursor-pointer">
                  <Camera className="w-4 h-4 mr-1.5" /> Re-scan ID
                  <input type="file" accept="image/*,application/pdf" className="hidden" onChange={handleIdUploadSimulate} />
                </label>
              </div>
            ) : (
              <label className="border-2 border-dashed border-gray-300 hover:border-brand-500 rounded-2xl p-10 text-center bg-gray-50 hover:bg-brand-50/30 transition-all cursor-pointer block group">
                <UploadCloud className="w-12 h-12 text-gray-400 group-hover:text-brand-500 mx-auto mb-3 transition-colors" />
                <span className="block font-bold text-gray-900 text-sm mb-1 group-hover:text-brand-600 transition-colors">Drag and drop or select NIN Slip / ID Card</span>
                <span className="block text-xs text-gray-500">Supports PDF, JPEG, PNG (Max 5MB)</span>
                
                <span className="mt-6 inline-flex items-center px-4 py-2 bg-brand-600 text-white hover:bg-brand-500 text-xs font-semibold rounded-xl transition-all shadow shadow-brand-500/20">
                  Select Document
                </span>
                <input type="file" accept="image/*,application/pdf" className="hidden" onChange={handleIdUploadSimulate} />
              </label>
            )}

            <button 
              type="button" 
              onClick={() => {
                // Instantly simulate scan to prevent blocking user
                const mockEvent = {
                  target: { files: [new File([""], "NIN_SLIP_SIMULATED.png")] }
                } as any;
                handleIdUploadSimulate(mockEvent);
              }}
              className="mt-6 text-xs text-brand-600 hover:text-brand-500 font-semibold underline flex items-center justify-center mx-auto"
            >
              ⚡ Sim-Click Demo Scan
            </button>
          </div>
        </div>
      );
    }

    // FORM MAPPING A: BUSINESS NAME (ENTERPRISE)
    if (stepId === 'ent-names') {
      return (
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Proposed Business Names</label>
            <p className="text-xs text-gray-500 mb-3">CAC guidelines require at least two distinct names in order of priority.</p>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-500 mb-1">Business Name Choice 1 (Primary)</label>
                <input 
                  type="text" 
                  value={intakeData.enterpriseDetails.proposedNames[0] || ''}
                  onChange={e => {
                    const list = [...intakeData.enterpriseDetails.proposedNames];
                    list[0] = e.target.value;
                    updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, proposedNames: list } });
                  }}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" 
                  placeholder="e.g. Sterling Ventures & Co"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-500 mb-1">Business Name Choice 2 (Alternative)</label>
                <input 
                  type="text" 
                  value={intakeData.enterpriseDetails.proposedNames[1] || ''}
                  onChange={e => {
                    const list = [...intakeData.enterpriseDetails.proposedNames];
                    list[1] = e.target.value;
                    updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, proposedNames: list } });
                  }}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" 
                  placeholder="e.g. Sterling Digital Hub"
                />
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (stepId === 'ent-personal') {
      const details = intakeData.enterpriseDetails.personalDetails;
      return (
        <div className="space-y-6">
          <div className="bg-brand-50 p-4 rounded-xl border border-brand-100 flex items-center">
            <UserCheck className="w-5 h-5 text-brand-500 mr-2" />
            <span className="text-xs text-brand-800 font-medium">Verify or complete the extracted details below.</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Surname</label>
              <input type="text" value={details.surname} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, surname: e.target.value } } });
              }} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
              <input type="text" value={details.firstName} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, firstName: e.target.value } } });
              }} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Other Name</label>
              <input type="text" value={details.otherName} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, otherName: e.target.value } } });
              }} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label>
              <input type="date" value={details.dob} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, dob: e.target.value } } });
              }} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
              <select value={details.gender} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, gender: e.target.value } } });
              }} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none">
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">NIN Number</label>
              <input type="text" maxLength={11} value={details.nin} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, nin: e.target.value } } });
              }} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" placeholder="11-digit National ID Number" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
              <input type="tel" value={details.phone} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, phone: e.target.value } } });
              }} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Functional Email Address</label>
              <input type="email" value={details.email} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, email: e.target.value } } });
              }} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none" />
            </div>
          </div>
        </div>
      );
    }

    if (stepId === 'ent-addresses') {
      const home = intakeData.enterpriseDetails.homeAddress;
      const biz = intakeData.enterpriseDetails.businessAddress;
      return (
        <div className="space-y-8">
          <div>
            <h4 className="heading-font font-bold text-lg text-gray-900 mb-4 pb-2 border-b border-gray-100">1. Residential (Home) Address</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">State</label>
                <input type="text" value={home.state} onChange={e => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, homeAddress: { ...home, state: e.target.value } } });
                }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. Lagos" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">LGA</label>
                <input type="text" value={home.lga} onChange={e => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, homeAddress: { ...home, lga: e.target.value } } });
                }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. Ikeja" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">City / Town / Village</label>
                <input type="text" value={home.city} onChange={e => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, homeAddress: { ...home, city: e.target.value } } });
                }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. Ikeja" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">House Number</label>
                <input type="text" value={home.houseNumber} onChange={e => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, homeAddress: { ...home, houseNumber: e.target.value } } });
                }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. 15" />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-700 mb-1">Street Name</label>
                <input type="text" value={home.streetName} onChange={e => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, homeAddress: { ...home, streetName: e.target.value } } });
                }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. Allen Avenue" />
              </div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-gray-100">
              <h4 className="heading-font font-bold text-lg text-gray-900">2. Official Business Address</h4>
              <button 
                type="button" 
                onClick={() => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, businessAddress: { ...home } } });
                }}
                className="text-xs text-brand-600 font-semibold hover:underline"
              >
                Same as Home Address
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">State</label>
                <input type="text" value={biz.state} onChange={e => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, businessAddress: { ...biz, state: e.target.value } } });
                }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">LGA</label>
                <input type="text" value={biz.lga} onChange={e => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, businessAddress: { ...biz, lga: e.target.value } } });
                }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">City / Town / Village</label>
                <input type="text" value={biz.city} onChange={e => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, businessAddress: { ...biz, city: e.target.value } } });
                }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">House Number</label>
                <input type="text" value={biz.houseNumber} onChange={e => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, businessAddress: { ...biz, houseNumber: e.target.value } } });
                }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-700 mb-1">Street Name</label>
                <input type="text" value={biz.streetName} onChange={e => {
                  updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, businessAddress: { ...biz, streetName: e.target.value } } });
                }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" />
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (stepId === 'ent-nature') {
      return (
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Nature of Business</label>
            <p className="text-xs text-gray-500 mb-3">Explain what services or products this business enterprise will offer.</p>
            <textarea 
              rows={4}
              value={intakeData.enterpriseDetails.natureOfBusiness}
              onChange={e => updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, natureOfBusiness: e.target.value } })}
              placeholder="e.g., General merchandise, import and export of medical equipments, fashion design retail..."
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none resize-none"
            />
          </div>
        </div>
      );
    }

    if (stepId === 'ent-docs') {
      const docs = intakeData.enterpriseDetails.documents;
      return (
        <div className="space-y-8">
          <div>
            <h4 className="font-bold text-gray-900 mb-2">Supporting Documents Upload</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="border border-gray-200 p-4 rounded-xl text-center bg-gray-50/50">
                <p className="text-xs font-semibold text-gray-700 mb-2">Passport Photograph</p>
                <label className="border-2 border-dashed border-gray-300 rounded-lg p-4 cursor-pointer hover:border-brand-500 block group">
                  <UploadCloud className="w-6 h-6 text-gray-400 mx-auto mb-1 group-hover:text-brand-500 transition-colors" />
                  <span className="text-xs text-gray-500">Upload (White BG)</span>
                  <input type="file" accept="image/*,application/pdf" className="hidden" onChange={handleGenericFileUpload} />
                </label>
              </div>
              <div className="border border-gray-200 p-4 rounded-xl text-center bg-gray-50/50">
                <p className="text-xs font-semibold text-gray-700 mb-2">National ID / NIN Slip File</p>
                <label className="border-2 border-dashed border-gray-300 rounded-lg p-4 cursor-pointer hover:border-brand-500 block group">
                  <UploadCloud className="w-6 h-6 text-gray-400 mx-auto mb-1 group-hover:text-brand-500 transition-colors" />
                  <span className="text-xs text-gray-500">Upload NIN PDF/JPG</span>
                  <input type="file" accept="image/*,application/pdf" className="hidden" onChange={handleGenericFileUpload} />
                </label>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-gray-900 mb-2">Digital Signature</h4>
            {docs.signatureUrl ? (
              <div className="border border-gray-200 rounded-xl p-4 bg-gray-50 text-center relative">
                <img src={docs.signatureUrl} alt="Signature" className="h-24 mx-auto" />
                <button 
                  type="button"
                  onClick={() => clearSignatureCanvas(sigCanvas, 'signatureUrl')} 
                  className="absolute top-2 right-2 text-xs text-red-600 font-semibold"
                >
                  Clear
                </button>
              </div>
            ) : (
              <div className="border border-gray-200 rounded-xl overflow-hidden bg-white shadow-inner">
                <SignatureCanvas 
                  ref={sigCanvas}
                  penColor="black"
                  canvasProps={{ className: 'w-full h-32 cursor-crosshair touch-none bg-gray-50/30' }} 
                />
                <div className="p-2.5 border-t border-gray-200 flex justify-between bg-gray-50">
                  <button type="button" onClick={() => sigCanvas.current?.clear()} className="px-3 py-1.5 text-xs font-medium text-gray-600 hover:text-gray-900">
                    Clear Drawing
                  </button>
                  <button type="button" onClick={() => saveSignatureCanvas(sigCanvas, 'signatureUrl')} className="px-4 py-1.5 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 rounded-lg">
                    Lock Signature
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      );
    }

    // FORM MAPPING B: LIMITED LIABILITY COMPANY
    if (stepId === 'names-objects') {
      const { proposedNames, objectsOfMemorandum } = intakeData.companyDetails;
      return (
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Proposed Corporate Names</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-xs text-gray-500 mb-1">Company Name Choice 1</label>
                <input 
                  type="text" 
                  value={proposedNames[0]} 
                  onChange={e => {
                    const list = [...proposedNames];
                    list[0] = e.target.value;
                    updateIntakeData({ companyDetails: { ...intakeData.companyDetails, proposedNames: list } });
                  }}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl"
                  placeholder="e.g. Apex Tech LTD"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-500 mb-1">Company Name Choice 2</label>
                <input 
                  type="text" 
                  value={proposedNames[1]} 
                  onChange={e => {
                    const list = [...proposedNames];
                    list[1] = e.target.value;
                    updateIntakeData({ companyDetails: { ...intakeData.companyDetails, proposedNames: list } });
                  }}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl"
                  placeholder="e.g. Apex Global Solution LTD"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Objects of Memorandum</label>
            <p className="text-xs text-gray-500 mb-3">Define what activities and business lines your company is authorized to conduct.</p>
            
            <div className="space-y-2 mb-4">
              {objectsOfMemorandum.map((obj, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-100">
                  <span className="text-sm font-medium text-gray-800">{obj}</span>
                  <button type="button" onClick={() => removeMemorandumObject(idx)} className="text-red-500 hover:text-red-600">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex space-x-2">
              <input 
                type="text" 
                value={tempObject}
                onChange={e => setTempObject(e.target.value)}
                placeholder="e.g. To carry on business of farming and agricultural supply"
                className="flex-1 px-4 py-2 border border-gray-200 rounded-xl text-sm"
              />
              <button 
                type="button" 
                onClick={addMemorandumObject}
                className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-500"
              >
                Add Object
              </button>
            </div>
          </div>
        </div>
      );
    }

    if (stepId === 'personal-ocr') {
      const details = intakeData.enterpriseDetails.personalDetails;
      return (
        <div className="space-y-6">
          <div className="bg-brand-50 p-4 rounded-xl border border-brand-100">
            <p className="text-xs text-brand-800 font-semibold">Primary Applicant information auto-extracted from ID scan. Make any necessary corrections below.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Surname</label>
              <input type="text" value={details.surname} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, surname: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-xl" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
              <input type="text" value={details.firstName} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, firstName: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-xl" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Other Name</label>
              <input type="text" value={details.otherName} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, otherName: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-xl" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label>
              <input type="date" value={details.dob} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, dob: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-xl" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
              <input type="text" value={details.gender} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, gender: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-xl" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">NIN/ID Number</label>
              <input type="text" value={details.nin} onChange={e => {
                updateIntakeData({ enterpriseDetails: { ...intakeData.enterpriseDetails, personalDetails: { ...details, nin: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-xl" />
            </div>
          </div>
        </div>
      );
    }

    if (stepId === 'directors') {
      const { directors } = intakeData.companyDetails;
      return (
        <div className="space-y-6">
          <p className="text-sm text-gray-600">Add information of all Company Directors. Minimum of 1 is required.</p>
          
          <div className="space-y-6">
            {directors.map((dir, idx) => (
              <div key={dir.id} className="p-5 border border-gray-200 rounded-2xl bg-gray-50/50 relative">
                {directors.length > 1 && (
                  <button 
                    type="button" 
                    onClick={() => {
                      const list = directors.filter(d => d.id !== dir.id);
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }}
                    className="absolute top-4 right-4 text-xs font-semibold text-red-600 hover:text-red-700 flex items-center"
                  >
                    <Trash2 className="w-3 h-3 mr-1" /> Remove
                  </button>
                )}
                <h4 className="font-bold text-gray-900 mb-4 heading-font text-base">Director {idx + 1}</h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Surname</label>
                    <input type="text" value={dir.surname} onChange={e => {
                      const list = [...directors];
                      list[idx].surname = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">First Name</label>
                    <input type="text" value={dir.firstName} onChange={e => {
                      const list = [...directors];
                      list[idx].firstName = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Other Name</label>
                    <input type="text" value={dir.otherName} onChange={e => {
                      const list = [...directors];
                      list[idx].otherName = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Date of Birth</label>
                    <input type="date" value={dir.dob} onChange={e => {
                      const list = [...directors];
                      list[idx].dob = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Gender</label>
                    <select value={dir.gender} onChange={e => {
                      const list = [...directors];
                      list[idx].gender = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm">
                      <option value="">Select</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Nationality</label>
                    <input type="text" value={dir.nationality} onChange={e => {
                      const list = [...directors];
                      list[idx].nationality = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Phone Number</label>
                    <input type="tel" value={dir.phone} onChange={e => {
                      const list = [...directors];
                      list[idx].phone = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Email Address</label>
                    <input type="email" value={dir.email} onChange={e => {
                      const list = [...directors];
                      list[idx].email = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">ID Type</label>
                    <select value={dir.idType} onChange={e => {
                      const list = [...directors];
                      list[idx].idType = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm">
                      <option value="NIN">NIN</option>
                      <option value="International Passport">International Passport</option>
                      <option value="Drivers License">Driver's License</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">ID Number</label>
                    <input type="text" value={dir.idNumber} onChange={e => {
                      const list = [...directors];
                      list[idx].idNumber = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>

                  <div className="md:col-span-3 mt-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Address: State</label>
                      <input type="text" value={dir.address.state} onChange={e => {
                        const list = [...directors];
                        list[idx].address.state = e.target.value;
                        updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                      }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Address: LGA</label>
                      <input type="text" value={dir.address.lga} onChange={e => {
                        const list = [...directors];
                        list[idx].address.lga = e.target.value;
                        updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                      }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Address: City</label>
                      <input type="text" value={dir.address.city} onChange={e => {
                        const list = [...directors];
                        list[idx].address.city = e.target.value;
                        updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                      }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Address: Street & House No</label>
                      <input type="text" value={dir.address.streetName} onChange={e => {
                        const list = [...directors];
                        list[idx].address.streetName = e.target.value;
                        updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
                      }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button 
            type="button" 
            onClick={() => {
              const list = [...directors, {
                id: `dir-${Date.now()}`,
                surname: '',
                firstName: '',
                otherName: '',
                dob: '',
                gender: '',
                nationality: 'Nigerian',
                phone: '',
                email: '',
                address: { state: '', lga: '', city: '', houseNumber: '', streetName: '' },
                idType: 'NIN',
                idNumber: '',
              }];
              updateIntakeData({ companyDetails: { ...intakeData.companyDetails, directors: list } });
            }}
            className="w-full py-4 border-2 border-dashed border-gray-300 rounded-2xl text-gray-600 font-medium hover:border-brand-500 hover:text-brand-600 hover:bg-brand-50 transition-colors"
          >
            + Add Another Director
          </button>
        </div>
      );
    }

    if (stepId === 'shareholders') {
      const { shareholders, directors } = intakeData.companyDetails;
      return (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600">Add information of all shareholders.</p>
            <button 
              type="button" 
              onClick={() => {
                // Instantly copy directors to shareholders for convenience
                const converted: DirectorShareholder[] = directors.map(d => ({
                  ...d,
                  id: `sh-${d.id}`,
                  shares: Math.floor(100 / directors.length),
                }));
                updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: converted } });
              }}
              className="text-xs text-brand-600 font-semibold hover:underline"
            >
              Copy Directors to Shareholders
            </button>
          </div>
          
          <div className="space-y-6">
            {shareholders.map((sh, idx) => (
              <div key={sh.id} className="p-5 border border-gray-200 rounded-2xl bg-gray-50/50 relative">
                {shareholders.length > 1 && (
                  <button 
                    type="button" 
                    onClick={() => {
                      const list = shareholders.filter(s => s.id !== sh.id);
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }}
                    className="absolute top-4 right-4 text-xs font-semibold text-red-600 hover:text-red-700 flex items-center"
                  >
                    <Trash2 className="w-3 h-3 mr-1" /> Remove
                  </button>
                )}
                <h4 className="font-bold text-gray-900 mb-4 heading-font text-base">Shareholder {idx + 1}</h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Surname</label>
                    <input type="text" value={sh.surname} onChange={e => {
                      const list = [...shareholders];
                      list[idx].surname = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">First Name</label>
                    <input type="text" value={sh.firstName} onChange={e => {
                      const list = [...shareholders];
                      list[idx].firstName = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Other Name</label>
                    <input type="text" value={sh.otherName} onChange={e => {
                      const list = [...shareholders];
                      list[idx].otherName = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Date of Birth</label>
                    <input type="date" value={sh.dob} onChange={e => {
                      const list = [...shareholders];
                      list[idx].dob = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Gender</label>
                    <select value={sh.gender} onChange={e => {
                      const list = [...shareholders];
                      list[idx].gender = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm">
                      <option value="">Select</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Nationality</label>
                    <input type="text" value={sh.nationality} onChange={e => {
                      const list = [...shareholders];
                      list[idx].nationality = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Phone Number</label>
                    <input type="tel" value={sh.phone} onChange={e => {
                      const list = [...shareholders];
                      list[idx].phone = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Email Address</label>
                    <input type="email" value={sh.email} onChange={e => {
                      const list = [...shareholders];
                      list[idx].email = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">ID Type</label>
                    <select value={sh.idType} onChange={e => {
                      const list = [...shareholders];
                      list[idx].idType = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm">
                      <option value="NIN">NIN</option>
                      <option value="International Passport">International Passport</option>
                      <option value="Drivers License">Driver's License</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">ID Number</label>
                    <input type="text" value={sh.idNumber} onChange={e => {
                      const list = [...shareholders];
                      list[idx].idNumber = e.target.value;
                      updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>

                  <div className="md:col-span-3 mt-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Address: State</label>
                      <input type="text" value={sh.address.state} onChange={e => {
                        const list = [...shareholders];
                        list[idx].address.state = e.target.value;
                        updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                      }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Address: LGA</label>
                      <input type="text" value={sh.address.lga} onChange={e => {
                        const list = [...shareholders];
                        list[idx].address.lga = e.target.value;
                        updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                      }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Address: City</label>
                      <input type="text" value={sh.address.city} onChange={e => {
                        const list = [...shareholders];
                        list[idx].address.city = e.target.value;
                        updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                      }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-1">Address: Street & House No</label>
                      <input type="text" value={sh.address.streetName} onChange={e => {
                        const list = [...shareholders];
                        list[idx].address.streetName = e.target.value;
                        updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                      }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button 
            type="button" 
            onClick={() => {
              const list = [...shareholders, {
                id: `sh-${Date.now()}`,
                surname: '',
                firstName: '',
                otherName: '',
                dob: '',
                gender: '',
                nationality: 'Nigerian',
                phone: '',
                email: '',
                address: { state: '', lga: '', city: '', houseNumber: '', streetName: '' },
                idType: 'NIN',
                idNumber: '',
                shares: 0,
              }];
              updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
            }}
            className="w-full py-4 border-2 border-dashed border-gray-300 rounded-2xl text-gray-600 font-medium hover:border-brand-500 hover:text-brand-600 hover:bg-brand-50 transition-colors"
          >
            + Add Another Shareholder
          </button>
        </div>
      );
    }

    if (stepId === 'share-capital') {
      const { shareholders, shareCapitalBreakdown } = intakeData.companyDetails;
      const totalSharesSum = shareholders.reduce((sum, s) => sum + (Number(s.shares) || 0), 0);
      return (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Total Number of Corporate Shares</label>
              <input 
                type="number" 
                value={shareCapitalBreakdown.totalShares} 
                onChange={e => {
                  updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareCapitalBreakdown: { ...shareCapitalBreakdown, totalShares: Number(e.target.value) } } });
                }}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl font-medium" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nominal Value Per Share (₦)</label>
              <input 
                type="number" 
                value={shareCapitalBreakdown.nominalValue} 
                onChange={e => {
                  updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareCapitalBreakdown: { ...shareCapitalBreakdown, nominalValue: Number(e.target.value) } } });
                }}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl" 
              />
            </div>
          </div>

          <div className="p-4 rounded-xl border flex items-center justify-between mt-6 bg-brand-50 border-brand-100">
            <div>
              <span className="text-xs font-semibold text-brand-800 uppercase tracking-wider block">Total Share equity allocation</span>
              <span className="text-xs text-brand-600">Must sum up to exactly 100% across all shareholders.</span>
            </div>
            <span className={`heading-font font-bold text-2xl ${totalSharesSum === 100 ? 'text-green-600' : 'text-red-600'}`}>
              {totalSharesSum}%
            </span>
          </div>

          <div className="space-y-4">
            {shareholders.map((sh, idx) => (
              <div key={sh.id} className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                <div>
                  <p className="font-bold text-gray-900">{sh.firstName} {sh.surname}</p>
                  <p className="text-xs text-gray-500">Shareholder {idx + 1}</p>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Percentage of Shares (%)</label>
                  <div className="relative w-36">
                    <input 
                      type="number" 
                      min="0" max="100"
                      value={sh.shares || ''}
                      onChange={e => {
                        const list = [...shareholders];
                        list[idx].shares = Number(e.target.value);
                        updateIntakeData({ companyDetails: { ...intakeData.companyDetails, shareholders: list } });
                      }}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg text-right pr-8 outline-none focus:ring-2 focus:ring-brand-500"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 font-bold text-gray-500 text-sm">%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }

    if (stepId === 'corp-witness') {
      const { witness } = intakeData.companyDetails;
      return (
        <div className="space-y-6">
          <h4 className="heading-font font-bold text-lg text-gray-900">Witness Identification</h4>
          <p className="text-xs text-gray-500">Provide legal witness information verifying the company registration formation.</p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Surname</label>
              <input type="text" value={witness.surname} onChange={e => {
                updateIntakeData({ companyDetails: { ...intakeData.companyDetails, witness: { ...witness, surname: e.target.value } } });
              }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">First Name</label>
              <input type="text" value={witness.firstName} onChange={e => {
                updateIntakeData({ companyDetails: { ...intakeData.companyDetails, witness: { ...witness, firstName: e.target.value } } });
              }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Other Name</label>
              <input type="text" value={witness.otherName} onChange={e => {
                updateIntakeData({ companyDetails: { ...intakeData.companyDetails, witness: { ...witness, otherName: e.target.value } } });
              }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Phone Number</label>
              <input type="tel" value={witness.phone} onChange={e => {
                updateIntakeData({ companyDetails: { ...intakeData.companyDetails, witness: { ...witness, phone: e.target.value } } });
              }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-gray-700 mb-1">Email Address</label>
              <input type="email" value={witness.email} onChange={e => {
                updateIntakeData({ companyDetails: { ...intakeData.companyDetails, witness: { ...witness, email: e.target.value } } });
              }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
            </div>

            <div className="sm:col-span-3 mt-4 border-t border-gray-100 pt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Witness State</label>
                <input type="text" value={witness.address.state} onChange={e => {
                  updateIntakeData({ companyDetails: { ...intakeData.companyDetails, witness: { ...witness, address: { ...witness.address, state: e.target.value } } } });
                }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Witness LGA</label>
                <input type="text" value={witness.address.lga} onChange={e => {
                  updateIntakeData({ companyDetails: { ...intakeData.companyDetails, witness: { ...witness, address: { ...witness.address, lga: e.target.value } } } });
                }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Witness City</label>
                <input type="text" value={witness.address.city} onChange={e => {
                  updateIntakeData({ companyDetails: { ...intakeData.companyDetails, witness: { ...witness, address: { ...witness.address, city: e.target.value } } } });
                }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Witness Street Address</label>
                <input type="text" value={witness.address.streetName} onChange={e => {
                  updateIntakeData({ companyDetails: { ...intakeData.companyDetails, witness: { ...witness, address: { ...witness.address, streetName: e.target.value } } } });
                }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (stepId === 'corp-docs') {
      return (
        <div className="space-y-6">
          <p className="text-sm text-gray-600">Please provide signatures and ID documentation uploads for the primary company applicant.</p>
          <div className="border border-gray-200 p-6 rounded-2xl bg-gray-50/50">
            <h4 className="font-bold text-sm text-gray-900 mb-2">Primary Director Passport (White Background)</h4>
            <label className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center bg-white cursor-pointer block group">
              <UploadCloud className="w-8 h-8 text-gray-400 mx-auto mb-2 group-hover:text-brand-500 transition-colors" />
              <span className="text-xs text-gray-500">Select Image (PNG / JPEG)</span>
              <input type="file" accept="image/*,application/pdf" className="hidden" onChange={handleGenericFileUpload} />
            </label>
          </div>
          
          <div className="border border-gray-200 p-6 rounded-2xl bg-gray-50/50">
            <h4 className="font-bold text-sm text-gray-900 mb-2">Authorized Signature Canvas</h4>
            <div className="border border-gray-200 rounded-xl overflow-hidden bg-white shadow-inner">
              <SignatureCanvas 
                ref={sigCanvas}
                penColor="black"
                canvasProps={{ className: 'w-full h-32 cursor-crosshair touch-none bg-gray-50/30' }} 
              />
              <div className="p-2 border-t border-gray-200 flex justify-between bg-gray-50">
                <button type="button" onClick={() => sigCanvas.current?.clear()} className="px-3 py-1 text-xs text-gray-600">Clear</button>
                <span className="text-xs text-gray-400">Draw above</span>
              </div>
            </div>
          </div>
        </div>
      );
    }

    // FORM MAPPING C: NGO & ASSOCIATION REGISTRATION
    if (stepId === 'ngo-rep') {
      const rep = intakeData.ngoDetails.representative;
      return (
        <div className="space-y-6">
          <div className="p-4 bg-brand-50 rounded-xl border border-brand-100">
            <h4 className="font-bold text-brand-900 text-sm mb-1">Section 1: Authorized Representative</h4>
            <p className="text-xs text-brand-700 leading-relaxed">
              This is the primary contact person for the registration process. All official communication from the CAC will be directed here.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Surname</label>
              <input type="text" value={rep.surname} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, representative: { ...rep, surname: e.target.value } } });
              }} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">First Name</label>
              <input type="text" value={rep.firstName} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, representative: { ...rep, firstName: e.target.value } } });
              }} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Other Name</label>
              <input type="text" value={rep.otherName} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, representative: { ...rep, otherName: e.target.value } } });
              }} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Date of Birth</label>
              <input type="date" value={rep.dob} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, representative: { ...rep, dob: e.target.value } } });
              }} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Gender</label>
              <select value={rep.gender} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, representative: { ...rep, gender: e.target.value } } });
              }} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm">
                <option value="">Select</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Nationality</label>
              <input type="text" value={rep.nationality} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, representative: { ...rep, nationality: e.target.value } } });
              }} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Phone Number</label>
              <input type="tel" value={rep.phone} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, representative: { ...rep, phone: e.target.value } } });
              }} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Email Address</label>
              <input type="email" value={rep.email} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, representative: { ...rep, email: e.target.value } } });
              }} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Occupation</label>
              <input type="text" value={rep.occupation} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, representative: { ...rep, occupation: e.target.value } } });
              }} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" />
            </div>
          </div>
        </div>
      );
    }

    if (stepId === 'ngo-names') {
      const { proposedNames, mission } = intakeData.ngoDetails;
      return (
        <div className="space-y-6">
          <div className="p-4 bg-brand-50 rounded-xl border border-brand-100">
            <h4 className="font-bold text-brand-900 text-sm mb-1">Section 2: Proposed Names & Mission</h4>
            <p className="text-xs text-brand-700 leading-relaxed">
              The CAC requires three name options in order of preference. If your first choice is already taken by another registered entity, they will check the second and third.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Proposed Name 1 (First Choice)</label>
              <input type="text" value={proposedNames[0]} onChange={e => {
                const list = [...proposedNames];
                list[0] = e.target.value;
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, proposedNames: list } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-xl" placeholder="e.g. Help Africa Foundation" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Proposed Name 2 (Second Choice)</label>
              <input type="text" value={proposedNames[1]} onChange={e => {
                const list = [...proposedNames];
                list[1] = e.target.value;
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, proposedNames: list } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-xl" placeholder="e.g. Save Africa Children Association" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Proposed Name 3 (Third Choice)</label>
              <input type="text" value={proposedNames[2]} onChange={e => {
                const list = [...proposedNames];
                list[2] = e.target.value;
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, proposedNames: list } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-xl" placeholder="e.g. Children Growth NGO" />
            </div>
          </div>

          <div className="border-t border-gray-100 pt-6">
            <label className="block text-sm font-semibold text-gray-900 mb-1">Description/Mission</label>
            <p className="text-xs text-gray-500 mb-2">Provide a clear 2–3 sentence summary of what your organization aims to achieve.</p>
            <textarea 
              rows={3} 
              value={mission}
              onChange={e => updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, mission: e.target.value } })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none resize-none"
              placeholder="e.g. To facilitate free quality STEM education to underprivileged youth in rural Nigeria, fostering local technological innovations..."
            />
          </div>
        </div>
      );
    }

    if (stepId === 'ngo-address') {
      const office = intakeData.ngoDetails.officeAddress;
      return (
        <div className="space-y-6">
          <div className="p-4 bg-brand-50 rounded-xl border border-brand-100">
            <h4 className="font-bold text-brand-900 text-sm mb-1">Section 3: Registered Office Address</h4>
            <p className="text-xs text-brand-700 leading-relaxed">
              This is the legal 'home' of your NGO. It must be a physical address in Nigeria.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">House Number / Building</label>
              <input type="text" value={office.houseNumber} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, officeAddress: { ...office, houseNumber: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. Plot 105" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Street Name</label>
              <input type="text" value={office.streetName} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, officeAddress: { ...office, streetName: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. Gwarinpa Way" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">City / Town / Village</label>
              <input type="text" value={office.city} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, officeAddress: { ...office, city: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. Abuja" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">LGA</label>
              <input type="text" value={office.lga} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, officeAddress: { ...office, lga: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. AMAC" />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-gray-700 mb-1">State</label>
              <input type="text" value={office.state} onChange={e => {
                updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, officeAddress: { ...office, state: e.target.value } } });
              }} className="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm" placeholder="e.g. FCT" />
            </div>
          </div>

          <div className="border-t border-gray-100 pt-6">
            <h4 className="font-bold text-gray-900 text-sm mb-1">Utility Bill Upload</h4>
            <p className="text-xs text-gray-500 mb-3">Note: You must attach a copy of a recent utility bill (e.g., electricity bill) to verify this address.</p>
            <label className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center bg-gray-50 hover:bg-gray-100 cursor-pointer block group">
              <UploadCloud className="w-8 h-8 text-gray-400 mx-auto mb-2 group-hover:text-brand-500 transition-colors" />
              <span className="text-xs font-semibold text-gray-800">Drag & Drop Utility Bill</span>
              <input type="file" accept="image/*,application/pdf" className="hidden" onChange={handleGenericFileUpload} />
            </label>
          </div>
        </div>
      );
    }

    if (stepId === 'ngo-trustees') {
      const { trustees } = intakeData.ngoDetails;
      return (
        <div className="space-y-6">
          <div className="p-4 bg-brand-50 rounded-xl border border-brand-100">
            <h4 className="font-bold text-brand-900 text-sm mb-1">Section 4: Board of Trustees (BOT)</h4>
            <p className="text-xs text-brand-700 leading-relaxed">
              Under Nigerian law, you must have a minimum of two (2) trustees. One must be designated as the Chairman, and one as the Secretary.
            </p>
          </div>

          <div className="space-y-6">
            {trustees.map((tr, idx) => (
              <div key={tr.id} className="p-5 border border-gray-200 rounded-2xl bg-gray-50/50 relative">
                {trustees.length > 2 && (
                  <button 
                    type="button" 
                    onClick={() => {
                      const list = trustees.filter(t => t.id !== tr.id);
                      updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, trustees: list } });
                    }}
                    className="absolute top-4 right-4 text-xs font-semibold text-red-600 hover:text-red-700 flex items-center"
                  >
                    <Trash2 className="w-3.5 h-3.5 mr-1" /> Remove
                  </button>
                )}
                <h4 className="font-bold text-gray-900 mb-4 heading-font">Trustee #{idx + 1}</h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-gray-700 mb-1">Full Name (matches NIN exactly)</label>
                    <input type="text" value={tr.fullName} onChange={e => {
                      const list = [...trustees];
                      list[idx].fullName = e.target.value;
                      updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, trustees: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Role Designation</label>
                    <select value={tr.role} onChange={e => {
                      const list = [...trustees];
                      list[idx].role = e.target.value;
                      updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, trustees: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm">
                      <option value="Chairman">Chairman</option>
                      <option value="Secretary">Secretary</option>
                      <option value="Treasurer">Treasurer</option>
                      <option value="Member">Member</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">NIN Number</label>
                    <input type="text" value={tr.nin} onChange={e => {
                      const list = [...trustees];
                      list[idx].nin = e.target.value;
                      updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, trustees: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Date of Birth</label>
                    <input type="date" value={tr.dob} onChange={e => {
                      const list = [...trustees];
                      list[idx].dob = e.target.value;
                      updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, trustees: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Gender</label>
                    <select value={tr.gender} onChange={e => {
                      const list = [...trustees];
                      list[idx].gender = e.target.value;
                      updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, trustees: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm">
                      <option value="">Select</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Occupation</label>
                    <input type="text" value={tr.occupation} onChange={e => {
                      const list = [...trustees];
                      list[idx].occupation = e.target.value;
                      updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, trustees: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-gray-700 mb-1">Residential Address</label>
                    <input type="text" value={tr.address} onChange={e => {
                      const list = [...trustees];
                      list[idx].address = e.target.value;
                      updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, trustees: list } });
                    }} className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm" />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 pt-4 border-t border-gray-150">
                  <div className="text-center">
                    <span className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Passport Photo (White BG)</span>
                    <div className="border border-dashed border-gray-300 bg-white rounded-lg p-3 text-xs text-gray-500 cursor-pointer">
                      Click to Upload
                    </div>
                  </div>
                  <div className="text-center">
                    <span className="block text-[10px] font-bold text-gray-500 uppercase mb-1">National ID (NIN)</span>
                    <div className="border border-dashed border-gray-300 bg-white rounded-lg p-3 text-xs text-gray-500 cursor-pointer">
                      Click to Upload NIN
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button 
            type="button" 
            onClick={() => {
              const list = [...trustees, {
                id: `trust-${Date.now()}`,
                fullName: '',
                role: 'Member',
                nin: '',
                dob: '',
                gender: '',
                occupation: '',
                address: '',
              }];
              updateIntakeData({ ngoDetails: { ...intakeData.ngoDetails, trustees: list } });
            }}
            className="w-full py-4 border-2 border-dashed border-gray-300 rounded-2xl text-gray-600 font-medium hover:border-brand-500 hover:text-brand-600 hover:bg-brand-50 transition-colors"
          >
            + Add Trustee
          </button>
        </div>
      );
    }

    if (stepId === 'ngo-aims') {
      const { aimsAndObjectives } = intakeData.ngoDetails;
      return (
        <div className="space-y-6">
          <div className="p-4 bg-brand-50 rounded-xl border border-brand-100">
            <h4 className="font-bold text-brand-900 text-sm mb-1">Section 5: Aims and Objectives</h4>
            <p className="text-xs text-brand-700 leading-relaxed">
              These define the scope of your NGO. They should be specific and aligned with your mission.
            </p>
          </div>

          <div className="space-y-2 mb-4">
            {aimsAndObjectives.map((aim, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-100">
                <span className="text-sm font-medium text-gray-800">{aim}</span>
                <button type="button" onClick={() => removeNgoObjective(idx)} className="text-red-500 hover:text-red-600">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          <div className="flex space-x-2">
            <input 
              type="text" 
              value={tempObjective}
              onChange={e => setTempObjective(e.target.value)}
              placeholder="e.g. To provide academic scholarships and mentorship programs..."
              className="flex-1 px-4 py-2 border border-gray-200 rounded-xl text-sm"
            />
            <button 
              type="button" 
              onClick={addNgoObjective}
              className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-500"
            >
              Add Objective
            </button>
          </div>
        </div>
      );
    }

    if (stepId === 'ngo-review') {
      return (
        <div className="space-y-6">
          <div className="p-5 bg-red-50 rounded-2xl border border-red-100 flex items-start">
            <AlertCircle className="w-6 h-6 text-red-600 mr-3 shrink-0 mt-0.5" />
            <div className="text-sm text-red-800 space-y-2 leading-relaxed">
              <h4 className="font-bold heading-font text-base text-red-900">Consultant Review & Submission</h4>
              <p>
                The Secretary is a statutory requirement for the board. Please ensure you clearly label who among your trustees will hold this position. Please ensure the names on your NIN match exactly. Discrepancies here are the most common reason for application delays. Once you submit this form, our team will review all details for compliance before initiating the official filing.
              </p>
            </div>
          </div>

          <div className="bg-white p-6 border border-gray-200 rounded-2xl space-y-4 shadow-sm">
            <h4 className="font-bold text-gray-900 heading-font">Summary of Submitted Data</h4>
            <div className="space-y-2 text-sm text-gray-600">
              <p><span className="font-semibold text-gray-800">Representative:</span> {intakeData.ngoDetails.representative.firstName} {intakeData.ngoDetails.representative.surname}</p>
              <p><span className="font-semibold text-gray-800">Proposed Name:</span> {intakeData.ngoDetails.proposedNames[0]}</p>
              <p><span className="font-semibold text-gray-800">Aims & Objectives Count:</span> {intakeData.ngoDetails.aimsAndObjectives.length}</p>
              <p><span className="font-semibold text-gray-800">Trustees count:</span> {intakeData.ngoDetails.trustees.length}</p>
            </div>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 py-12 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto w-full">
        <div className="mb-8">
          <h1 className="heading-font text-3xl font-bold text-gray-900 mb-2">
            {selectedPackage.name} Wizard
          </h1>
          <p className="text-gray-600 text-sm">Please complete all steps accurately to prevent CAC regulatory query issues.</p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl border border-gray-200 overflow-hidden flex flex-col md:flex-row min-h-[550px]">
          
          {/* Sidebar */}
          <div className="md:w-72 bg-gray-50 border-r border-gray-200 p-6 md:p-8 shrink-0 hidden sm:block">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-6">Wizard Steps</h3>
            <ul className="space-y-4">
              {steps.map((step, idx) => {
                const isCompleted = idx < currentStep;
                const isCurrent = idx === currentStep;
                return (
                  <li key={step.id} className="flex items-start">
                    <div className={`mt-0.5 w-5 h-5 rounded-full flex items-center justify-center shrink-0 mr-3 border ${
                      isCompleted ? 'bg-brand-500 border-brand-500 text-white' : 
                      isCurrent ? 'bg-white border-brand-500 text-brand-500 font-bold' : 'bg-transparent border-gray-300'
                    }`}>
                      {isCompleted ? <Check className="w-3 h-3" /> : <span className="text-[10px]">{idx + 1}</span>}
                    </div>
                    <span className={`text-xs font-semibold ${isCurrent ? 'text-gray-900' : 'text-gray-400'}`}>{step.title}</span>
                  </li>
                );
              })}
            </ul>
          </div>

          {/* Mobile step indicator */}
          <div className="sm:hidden p-4 border-b border-gray-100 bg-gray-50">
            <p className="text-xs font-medium text-brand-600 mb-1">Step {currentStep + 1} of {steps.length}</p>
            <p className="font-bold text-gray-900 text-sm">{steps[currentStep].title}</p>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 p-6 md:p-10 flex flex-col relative overflow-y-auto">
            
            <div className="flex-1">
              <h2 className="heading-font text-xl font-bold text-gray-900 mb-6 hidden sm:block">{steps[currentStep].title}</h2>
              
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentStep}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.15 }}
                >
                  {renderStepContent()}
                </motion.div>
              </AnimatePresence>
            </div>

            {error && (
              <div className="mt-6 p-4 bg-red-50 text-red-700 text-sm rounded-xl flex items-start border border-red-100">
                <AlertCircle className="w-5 h-5 mr-2 shrink-0 mt-0.5" />
                {error}
              </div>
            )}

            <div className="mt-10 pt-6 border-t border-gray-100 flex items-center justify-between sticky bottom-0 bg-white">
              <button 
                type="button"
                onClick={handleBack}
                className={`px-6 py-2.5 rounded-xl font-medium text-sm transition-colors flex items-center ${currentStep === 0 ? 'invisible' : 'text-gray-600 hover:bg-gray-100'}`}
              >
                <ArrowLeft className="w-4 h-4 mr-2" /> Back
              </button>
              
              <button 
                type="button"
                onClick={handleNext}
                className="px-8 py-2.5 bg-gray-900 hover:bg-gray-800 text-white rounded-xl font-medium text-sm transition-colors shadow-md flex items-center"
              >
                {currentStep === steps.length - 1 ? 'Submit Application' : 'Save & Continue'}
                {currentStep !== steps.length - 1 && <ArrowRight className="w-4 h-4 ml-2" />}
              </button>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}
