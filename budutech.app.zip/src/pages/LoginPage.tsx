import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';
import { Mail, ArrowRight, ShieldCheck, Key, ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'email' | 'code'>('email');
  const [isVerifying, setIsVerifying] = useState(false);
  const { setUser, selectedPackage } = useAppStore();
  const navigate = useNavigate();

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setStep('code');
  };

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.length < 6) return;
    setIsVerifying(true);
    
    // Simulate verification
    setTimeout(() => {
      // If admin email
      if (email === 'admin@budutech.app' || email === 'budutech1@gmail.com') {
        setUser({ email, role: 'admin' });
        navigate('/admin');
      } else {
        setUser({ email, role: 'client' });
        if (selectedPackage) {
          navigate('/checkout');
        } else {
          navigate('/dashboard');
        }
      }
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="w-12 h-12 bg-brand-600 rounded-xl flex items-center justify-center shadow-lg shadow-brand-500/30">
            <span className="text-white font-bold heading-font text-2xl">B</span>
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900 heading-font">
          Access BuduFlow
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Secure, passwordless client portal
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-xl shadow-gray-200/50 sm:rounded-2xl sm:px-10 border border-gray-100 relative overflow-hidden">
          
          <motion.div 
            initial={false}
            animate={{ opacity: step === 'email' ? 1 : 0, x: step === 'email' ? 0 : -20 }}
            className={step === 'email' ? '' : 'pointer-events-none absolute inset-0 p-8 sm:p-10'}
          >
            <form className="space-y-6" onSubmit={handleSendEmail}>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email address
                </label>
                <div className="mt-2 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="block w-full pl-10 pr-3 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all sm:text-sm"
                    placeholder="you@example.com"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white bg-gray-900 hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900 transition-all"
              >
                Send Login Code <ArrowRight className="ml-2 w-4 h-4" />
              </button>
              
              <div className="flex items-center justify-center mt-4 text-xs text-gray-500">
                <ShieldCheck className="w-4 h-4 mr-1 text-green-600" />
                256-bit Secure Authentication
              </div>
            </form>
          </motion.div>

          {step === 'code' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="absolute inset-0 bg-white p-8 sm:p-10 flex flex-col items-center justify-center text-center"
            >
              <button 
                type="button" 
                onClick={() => setStep('email')} 
                className="absolute top-6 left-6 text-gray-400 hover:text-gray-600"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>

              <div className="w-16 h-16 bg-brand-50 rounded-full flex items-center justify-center mb-6">
                <Key className="w-8 h-8 text-brand-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2 heading-font">Enter Verification Code</h3>
              <p className="text-gray-600 text-sm mb-6">
                We've simulated sending a code to <span className="font-semibold text-gray-900">{email}</span>. 
                <br/><span className="text-brand-600 font-semibold text-xs mt-1 block">(Demo: Enter any 6 digits to proceed)</span>
              </p>

              <form onSubmit={handleVerifyCode} className="w-full space-y-6">
                <div>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                    className="block w-full text-center tracking-widest text-2xl py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all font-mono"
                    placeholder="000000"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isVerifying || code.length < 6}
                  className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white bg-brand-600 hover:bg-brand-700 disabled:opacity-70 transition-all"
                >
                  {isVerifying ? (
                    <div className="w-5 h-5 rounded-full border-2 border-white border-t-transparent animate-spin" />
                  ) : (
                    'Verify & Sign In'
                  )}
                </button>
              </form>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
