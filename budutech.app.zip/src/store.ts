import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type PackageType = 'corporate' | 'enterprise' | 'ngo' | 'upgrade';

export interface Package {
  id: string;
  name: string;
  price: number;
  type: PackageType;
  features: string[];
}

export interface User {
  email: string;
  role: 'client' | 'admin';
}

export interface Address {
  state: string;
  lga: string;
  city: string;
  houseNumber: string;
  streetName: string;
}

export interface EnterpriseDetails {
  proposedNames: string[]; // Business Name 1, Business Name 2
  personalDetails: {
    surname: string;
    firstName: string;
    otherName: string;
    dob: string;
    gender: string;
    phone: string;
    email: string;
    nin: string;
  };
  homeAddress: Address;
  businessAddress: Address;
  natureOfBusiness: string;
  documents: {
    ninSlipUrl?: string;
    passportPhotoUrl?: string;
    signatureUrl?: string;
  };
}

export interface DirectorShareholder {
  id: string;
  surname: string;
  firstName: string;
  otherName: string;
  dob: string;
  gender: string;
  nationality: string;
  phone: string;
  email: string;
  address: Address;
  idType: string;
  idNumber: string;
  shares?: number; // percentage of equity share (used for shareholders)
  idCardUrl?: string;
  signatureUrl?: string;
  passportPhotoUrl?: string;
}

export interface CompanyDetails {
  proposedNames: string[]; // Company Name 1, Company Name 2
  objectsOfMemorandum: string[]; // list of objects
  directors: DirectorShareholder[];
  shareholders: DirectorShareholder[];
  shareCapitalBreakdown: {
    totalShares: number;
    nominalValue: number;
    numShareholders: number;
  };
  witness: {
    surname: string;
    firstName: string;
    otherName: string;
    phone: string;
    email: string;
    address: Address;
  };
}

export interface Trustee {
  id: string;
  fullName: string;
  role: string; // Chairman, Secretary, Treasurer, Member
  nin: string;
  dob: string;
  gender: string;
  occupation: string;
  address: string;
  passportPhotoUrl?: string;
  ninUploadUrl?: string;
}

export interface NgoDetails {
  representative: {
    surname: string;
    firstName: string;
    otherName: string;
    dob: string;
    gender: string;
    nationality: string;
    phone: string;
    email: string;
    occupation: string;
  };
  proposedNames: string[]; // Proposed Name 1, Proposed Name 2, Proposed Name 3
  mission: string;
  officeAddress: {
    houseNumber: string;
    streetName: string;
    city: string;
    lga: string;
    state: string;
  };
  utilityBillUrl?: string;
  trustees: Trustee[];
  aimsAndObjectives: string[];
}

export interface IntakeData {
  idScanCompleted: boolean;
  scannedIdUrl: string | null;
  scannedIdName: string | null;
  enterpriseDetails: EnterpriseDetails;
  companyDetails: CompanyDetails;
  ngoDetails: NgoDetails;
}

export interface ClientProfile {
  id: string;
  email: string;
  package: Package;
  status: 'payment_pending' | 'intake' | 'review' | 'filed' | 'completed';
  intakeData: IntakeData;
  actionNeeded: string | null;
  submittedAt?: string;
  progress: number;
}

export interface AppState {
  user: User | null;
  setUser: (user: User | null) => void;
  selectedPackage: Package | null;
  setSelectedPackage: (pkg: Package | null) => void;
  intakeData: IntakeData;
  updateIntakeData: (data: Partial<IntakeData>) => void;
  resetIntakeData: () => void;
  applicationStatus: 'payment_pending' | 'intake' | 'review' | 'filed' | 'completed';
  setApplicationStatus: (status: AppState['applicationStatus']) => void;
  actionNeeded: string | null;
  setActionNeeded: (action: string | null) => void;
  
  // Admin mock state
  clients: ClientProfile[];
  updateClient: (id: string, updates: Partial<ClientProfile>) => void;
  addClient: (client: ClientProfile) => void;
}

const initialAddress: Address = {
  state: '',
  lga: '',
  city: '',
  houseNumber: '',
  streetName: '',
};

export const initialIntakeData: IntakeData = {
  idScanCompleted: false,
  scannedIdUrl: null,
  scannedIdName: null,
  enterpriseDetails: {
    proposedNames: ['', ''],
    personalDetails: {
      surname: '',
      firstName: '',
      otherName: '',
      dob: '',
      gender: '',
      phone: '',
      email: '',
      nin: '',
    },
    homeAddress: { ...initialAddress },
    businessAddress: { ...initialAddress },
    natureOfBusiness: '',
    documents: {},
  },
  companyDetails: {
    proposedNames: ['', ''],
    objectsOfMemorandum: ['1. Sale and supply of general merchandise'],
    directors: [],
    shareholders: [],
    shareCapitalBreakdown: {
      totalShares: 1000000,
      nominalValue: 1,
      numShareholders: 1,
    },
    witness: {
      surname: '',
      firstName: '',
      otherName: '',
      phone: '',
      email: '',
      address: { ...initialAddress },
    },
  },
  ngoDetails: {
    representative: {
      surname: '',
      firstName: '',
      otherName: '',
      dob: '',
      gender: '',
      nationality: 'Nigerian',
      phone: '',
      email: '',
      occupation: '',
    },
    proposedNames: ['', '', ''],
    mission: '',
    officeAddress: {
      houseNumber: '',
      streetName: '',
      city: '',
      lga: '',
      state: '',
    },
    utilityBillUrl: undefined,
    trustees: [],
    aimsAndObjectives: ['1. To promote social and economic welfare of the community.'],
  },
};

// Mock initial admin profiles
const mockClients: ClientProfile[] = [
  {
    id: 'client-1',
    email: 'john@example.com',
    package: { id: 'corp', name: 'Corporate Registration', price: 120000, type: 'corporate', features: [] },
    status: 'review',
    progress: 100,
    actionNeeded: null,
    submittedAt: '2026-07-01',
    intakeData: {
      idScanCompleted: true,
      scannedIdUrl: 'https://images.unsplash.com/photo-1554774853-aae0a22c8aa4?w=500',
      scannedIdName: 'NIN_SLIP_DOE.pdf',
      enterpriseDetails: {
        proposedNames: ['Acme Enterprises', 'Acme Global Venture'],
        personalDetails: {
          surname: 'Doe',
          firstName: 'John',
          otherName: 'Michael',
          dob: '1990-01-01',
          gender: 'Male',
          phone: '08031234567',
          email: 'john@example.com',
          nin: '12345678901',
        },
        homeAddress: { state: 'Lagos', lga: 'Ikeja', city: 'Ikeja', houseNumber: '12', streetName: 'Allen Avenue' },
        businessAddress: { state: 'Lagos', lga: 'Ikeja', city: 'Ikeja', houseNumber: '14', streetName: 'Joel Ogunnaike' },
        natureOfBusiness: 'Technology Consulting',
        documents: {},
      },
      companyDetails: {
        proposedNames: ['Acme Global Tech LTD', 'Acme Consulting LTD'],
        objectsOfMemorandum: ['1. Tech Consulting and IT Support', '2. General trading and logistics'],
        directors: [
          {
            id: 'dir-1',
            surname: 'Doe',
            firstName: 'John',
            otherName: 'Michael',
            dob: '1990-01-01',
            gender: 'Male',
            nationality: 'Nigerian',
            phone: '08031234567',
            email: 'john@example.com',
            address: { state: 'Lagos', lga: 'Ikeja', city: 'Ikeja', houseNumber: '12', streetName: 'Allen Avenue' },
            idType: 'NIN',
            idNumber: '12345678901',
            idCardUrl: 'scanned_id.jpg',
          }
        ],
        shareholders: [
          {
            id: 'sh-1',
            surname: 'Doe',
            firstName: 'John',
            otherName: 'Michael',
            dob: '1990-01-01',
            gender: 'Male',
            nationality: 'Nigerian',
            phone: '08031234567',
            email: 'john@example.com',
            address: { state: 'Lagos', lga: 'Ikeja', city: 'Ikeja', houseNumber: '12', streetName: 'Allen Avenue' },
            idType: 'NIN',
            idNumber: '12345678901',
            shares: 100,
          }
        ],
        shareCapitalBreakdown: {
          totalShares: 1000000,
          nominalValue: 1,
          numShareholders: 1,
        },
        witness: {
          surname: 'Smith',
          firstName: 'Robert',
          otherName: '',
          phone: '08098765432',
          email: 'robert@example.com',
          address: { state: 'Lagos', lga: 'Ikeja', city: 'Ikeja', houseNumber: '44', streetName: 'Toyin Street' },
        },
      },
      ngoDetails: {
        representative: {
          surname: 'Doe',
          firstName: 'John',
          otherName: '',
          dob: '1990-01-01',
          gender: 'Male',
          nationality: 'Nigerian',
          phone: '08031234567',
          email: 'john@example.com',
          occupation: 'Consultant',
        },
        proposedNames: ['Acme Hope Foundation', 'Acme Support Foundation', 'Acme Charity Foundation'],
        mission: 'To foster IT learning for underprivileged children.',
        officeAddress: { houseNumber: '12', streetName: 'Allen Avenue', city: 'Ikeja', lga: 'Ikeja', state: 'Lagos' },
        trustees: [],
        aimsAndObjectives: ['1. IT education promotion.'],
      },
    },
  },
  {
    id: 'client-2',
    email: 'ngo@example.com',
    package: { id: 'ngo', name: 'NGO / Foundation Registration', price: 200000, type: 'ngo', features: [] },
    status: 'intake',
    progress: 40,
    actionNeeded: 'ID document unreadable. Please re-upload.',
    submittedAt: '2026-07-03',
    intakeData: {
      idScanCompleted: true,
      scannedIdUrl: 'https://images.unsplash.com/photo-1554774853-aae0a22c8aa4?w=500',
      scannedIdName: 'NIN_SLIP.pdf',
      enterpriseDetails: {
        proposedNames: ['', ''],
        personalDetails: { surname: '', firstName: '', otherName: '', dob: '', gender: '', phone: '', email: '', nin: '' },
        homeAddress: { ...initialAddress },
        businessAddress: { ...initialAddress },
        natureOfBusiness: '',
        documents: {},
      },
      companyDetails: {
        proposedNames: ['', ''],
        objectsOfMemorandum: [],
        directors: [],
        shareholders: [],
        shareCapitalBreakdown: { totalShares: 0, nominalValue: 0, numShareholders: 0 },
        witness: { surname: '', firstName: '', otherName: '', phone: '', email: '', address: { ...initialAddress } },
      },
      ngoDetails: {
        representative: {
          surname: 'Smith',
          firstName: 'Alice',
          otherName: 'Grace',
          dob: '1985-02-02',
          gender: 'Female',
          nationality: 'Nigerian',
          phone: '09012345678',
          email: 'alice@example.com',
          occupation: 'Social Worker',
        },
        proposedNames: ['Help Africa Foundation', 'African Children Uplift', 'Empower Rural Women'],
        mission: 'Charity and education empowerment across Africa.',
        officeAddress: { houseNumber: '5A', streetName: 'Gwarinpa Estate', city: 'Abuja', lga: 'AMAC', state: 'FCT' },
        utilityBillUrl: 'utility.pdf',
        trustees: [
          {
            id: 'trust-1',
            fullName: 'Alice Grace Smith',
            role: 'Chairman',
            nin: '98765432101',
            dob: '1985-02-02',
            gender: 'Female',
            occupation: 'Social Worker',
            address: '5A Gwarinpa Estate, Abuja',
          },
          {
            id: 'trust-2',
            fullName: 'David Kalu',
            role: 'Secretary',
            nin: '11223344556',
            dob: '1980-05-15',
            gender: 'Male',
            occupation: 'Teacher',
            address: '10 Wuse Zone 2, Abuja',
          }
        ],
        aimsAndObjectives: [
          '1. To establish quality primary school assistance.',
          '2. To provide clean water and micro-grants.'
        ],
      },
    },
  }
];

const sanitizeString = (str: string) => {
  return str.replace(/<[^>]*>?/gm, '');
};

const deepSanitize = (obj: any): any => {
  if (typeof obj === 'string') {
    return sanitizeString(obj);
  }
  if (Array.isArray(obj)) {
    return obj.map(deepSanitize);
  }
  if (typeof obj === 'object' && obj !== null) {
    const newObj: any = {};
    for (const key in obj) {
      newObj[key] = deepSanitize(obj[key]);
    }
    return newObj;
  }
  return obj;
};

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      setUser: (user) => set({ user }),
      selectedPackage: null,
      setSelectedPackage: (pkg) => set({ selectedPackage: pkg }),
      intakeData: initialIntakeData,
      updateIntakeData: (data) => set((state) => ({ intakeData: { ...state.intakeData, ...deepSanitize(data) } })),
      resetIntakeData: () => set({ intakeData: initialIntakeData }),
      applicationStatus: 'payment_pending',
      setApplicationStatus: (status) => set({ applicationStatus: status }),
      actionNeeded: null,
      setActionNeeded: (action) => set({ actionNeeded: action }),
      
      clients: mockClients,
      updateClient: (id, updates) => set((state) => ({
        clients: state.clients.map(c => c.id === id ? { ...c, ...updates } : c)
      })),
      addClient: (client) => set((state) => ({
        clients: [client, ...state.clients]
      }))
    }),
    {
      name: 'budutech-flow-storage', // localstorage key
      partialize: (state) => ({
        user: state.user,
        selectedPackage: state.selectedPackage,
        intakeData: state.intakeData,
        applicationStatus: state.applicationStatus,
        actionNeeded: state.actionNeeded,
      }),
    }
  )
);
