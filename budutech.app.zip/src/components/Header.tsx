import { Link, useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';
import { LogOut } from 'lucide-react';

export default function Header() {
  const { user, setUser } = useAppStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    setUser(null);
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold heading-font text-xl">B</span>
          </div>
          <span className="font-bold heading-font text-xl tracking-tight text-brand-900">
            BuduTech
          </span>
        </Link>
        
        <nav className="hidden md:flex space-x-8">
          <a href="/#services" className="text-gray-600 hover:text-brand-600 font-medium transition-colors">Services</a>
          <a href="/#how-it-works" className="text-gray-600 hover:text-brand-600 font-medium transition-colors">How It Works</a>
          <a href="/#pricing" className="text-gray-600 hover:text-brand-600 font-medium transition-colors">Pricing</a>
        </nav>

        <div className="flex items-center space-x-4">
          {user ? (
            <div className="flex items-center space-x-4">
              <Link 
                to={user.role === 'admin' ? "/admin" : "/dashboard"} 
                className="text-sm font-medium text-gray-700 hover:text-brand-600"
              >
                {user.role === 'admin' ? "Admin Hub" : "My Dashboard"}
              </Link>
              <button 
                onClick={handleLogout}
                className="p-2 text-gray-500 hover:text-gray-900 transition-colors rounded-full hover:bg-gray-100"
                title="Logout"
              >
                <LogOut size={20} />
              </button>
            </div>
          ) : (
            <>
              <Link 
                to="/login" 
                className="text-sm font-medium text-gray-600 hover:text-brand-600 transition-colors"
              >
                Client Login
              </Link>
              <Link 
                to="/#pricing" 
                className="hidden sm:inline-flex items-center justify-center px-5 py-2.5 border border-transparent text-sm font-medium rounded-full text-white bg-brand-600 hover:bg-brand-500 transition-all shadow-sm hover:shadow-md"
              >
                Get Started
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
